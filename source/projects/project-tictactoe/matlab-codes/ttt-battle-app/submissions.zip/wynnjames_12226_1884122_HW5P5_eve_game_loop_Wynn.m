% HR: none
% James Wynn
% 11/14/2023
% 
% HW 5 P 5
% Player v Enemy game loop

function game_state = HW5P5_eve_game_loop_Wynn(game_state)

    if game_state.ai_X_level == 1

        ai_X = @HW4P9_dumb_ai_move_Wynn;

    elseif game_state.ai_X_level == 2

        ai_X = @HW5P1_better_ai_move_Wynn;

    elseif game_state.ai_X_level == 3

        ai_X = @HW5P2_my_ai_move_Wynn;

    end

    if game_state.ai_O_level == 1

        ai_O = @HW4P9_dumb_ai_move_Wynn;

    elseif game_state.ai_O_level == 2

        ai_O = @HW5P1_better_ai_move_Wynn;

    elseif game_state.ai_O_level == 3

        ai_O = @HW5P2_my_ai_move_Wynn;

    end


    while game_state.round < 9

        if game_state.player == 1

            index = ai_X(game_state);
            [x_click, y_click] = HW4P6_index_2_click_Wynn(index);
            game_state.x_click = x_click;
            game_state.y_click = y_click;

        elseif game_state.player == -1

            index = ai_O(game_state);
            [x_click, y_click] = HW4P6_index_2_click_Wynn(index);
            game_state.x_click = x_click;
            game_state.y_click = y_click;

        end

        game_state.empty_space(index) = false;
        game_state.data(index) = game_state.player;

        HW4P4_update_board_Wynn(game_state);
        game_state.round = game_state.round + 1;

        win = HW4P8_winner_check_Wynn(game_state.data);

        if game_state.player == 1

            game_state.whos_turn = 'X';

        elseif game_state.player == -1

            game_state.whos_turn = 'O';

        end

        if win ~= 0

            game_state.winner = game_state.player;
            return

        end
    
        game_state.player = game_state.player * -1;

    end
end


% =========================================================================
% HW 4 P 4
% Plots X or O in a given space on the board

function HW4P4_update_board_Wynn(game_state)

    x = game_state.x_click;
    y = game_state.y_click;

    if game_state.player == 1

        x = x + .15;
        y = y + .55;
        text(x,y,'X', 'Color','blue','FontSize',90)

    elseif game_state.player == -1

        x = x + .1;
        y = y + .55;
        text(x,y,'O', 'Color','red','FontSize',90)

    end
end

% =========================================================================
% HW 4 P 6
% Produces coordinates based on absolute indexing

function [x, y] = HW4P6_index_2_click_Wynn(k)
% [x, y] = HW4P6_index_2_click_Wynn()

    A = [3 2 1 ; 6 5 4; 9 8 7];

    for i = 1:3
        for j = 1:3
            if A(i,j) == k
                x = i;
                y = j;
            end
        end
    end
    
end

% =========================================================================
% HW 4 P 8
% Returns ttt winner

function result = HW4P8_winner_check_Wynn(data)

    diag_sum = sum(data(1,1) + data(2,2) + data(3,3));
    adiag_sum = sum(data(3,1) + data(2,2) + data(1,3));

    for i = 1:3
    
        col_sum = sum(data(i,:));
        row_sum = sum(data(:,i));
    
        if col_sum == 3 || row_sum == 3 || diag_sum == 3 || adiag_sum == 3
    
            result = 1;
            return
    
        elseif col_sum == -3 || row_sum == -3 || diag_sum == -3 || adiag_sum == -3
    
            result = -1;
            return
    
        else
    
            result = 0;
    
        end
    end
end

% =========================================================================
% HW 4 P 9
% Returns an AI move on available ttt space with equal probability

function index = HW4P9_dumb_ai_move_Wynn(game_state)

    n = 0;

    matrix = game_state.data;
    spaces = game_state.empty_space;

    for k = 1:10
    
        if k == 10

            index = [];
            return

        elseif spaces(k) == 1

            while n ~= 1

                index = randi(9);
                valid = matrix(index);
                
                if valid == 0
        
                    n = 1;
                    return 
        
                else
        
                    n = 0;
        
                end
            end
        end
    end
end