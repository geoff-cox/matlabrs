function state = HW5P5_eve_game_loop_DOUGHERTY(state , ai_X_level , ai_O_level)

game_over = HW4P8_winner_check_DOUGHERTY(state.data);

while game_over == 0
    if state.round > 8
        break
    end

    if state.player == 1

        if ai_X_level == 1
            selection = HW4P9_dumb_ai_move_DOUGHERTY(state)
        elseif ai_X_level == 2
            selection = HW5P1_better_ai_move_DOUGHERTY(state)
        elseif ai_X_level == 3
            selection = HW5P2_my_ai_move_DOUGHERTY(state)
        end

        [state.x , state.y] = HW4P6_index_2_click_DOUGHERTY(selection)
        HW4P4_update_board_DOUGHERTY(state)

        state.data(selection) = 1;

        state.round = state.round + 1;

        game_over = HW4P8_winner_check_DOUGHERTY(state.data);

        if game_over == 1
            state.winner = 1;
            state.empty_space(selection) = 0;
            break
        end
            
        state.whos_turn = 'O';

        state.player = -1;

        state.empty_space(selection) = 0;

    elseif state.player == -1
        if ai_O_level == 1
            selection = HW4P9_dumb_ai_move_DOUGHERTY(state.data);
        elseif ai_O_level == 2
            selection = HW5P1_better_ai_move_DOUGHERTY(state);
        elseif ai_O_level == 3
            selection = HW5P2_my_ai_move_DOUGHERTY(state);
        end
        
        [state.x , state.y] = HW4P6_index_2_click_DOUGHERTY(selection);
        HW4P4_update_board_DOUGHERTY(state)

        state.data(selection) = -1;

        state.round = state.round + 1;

        game_over = HW4P8_winner_check_DOUGHERTY(state.data);

        if game_over == -1
            state.winner = -1;
            state.empty_space(selection) = 0;
        end

        state.whos_turn = 'X';

        state.player = 1;

        state.empty_space(selection) = 0;

    end

end
end

function result = HW4P8_winner_check_DOUGHERTY(data)

result = 0;
a = HW3P10_row_col_diag_sums_DOUGHERTY(data);
A = a';
i = length(A);
for n = 1 : i
    if abs(A(n)) == 3
        if A(n) == 3
            result = 1;
            break
        elseif A(n) == -3
            result = -1;
            break
        end
    end
end

end

function sum_list = HW3P10_row_col_diag_sums_DOUGHERTY(A)
[m , n] = size(A);
sum_list = [];

for k = 1 : m
    Sum = 0;
    for j = 1 : n
        Sum = Sum + A(k , j);
    end
    sum_list = [sum_list ; Sum];
end

for k = 1 : n
    Sum = 0;
    for j = 1 : m
        Sum = Sum + A(j , k);
    end
    sum_list = [sum_list ; Sum];
end

if m < n
    Sum = 0;
    for k = 1 : m
        Sum = Sum + A(k , k);
    end
    sum_list = [sum_list ; Sum];
else
    Sum = 0;
    for k = 1 : n
        Sum = Sum + A(k , k);
    end
    sum_list = [sum_list ; Sum];
end


Sum = 0;
q = 1;
if m < n
    while m >= 1
        Sum = Sum +  A(m , q);
        q = q + 1;
        m = m - 1;
    end
else
    while n >= 1
        Sum = Sum + A(m , q);
        q = q + 1;
        m = m - 1;
        n = n - 1;
    end
end

sum_list = [sum_list ; Sum];

end

function HW4P4_update_board_DOUGHERTY(state)

if state.player == 1
    text(state.x + 0.15 , state.y + 0.54 , 'X' , 'Color' , 'blue' , 'Fontsize' , 70)
elseif state.player == -1
    text(state.x + 0.08 , state.y + 0.53 , 'O' , 'Color' , 'blue' , 'Fontsize' , 70)
end

end

function selection = HW4P9_dumb_ai_move_DOUGHERTY(state)

state_absolute = abs(state);
total = sum(sum(state_absolute));

if total == 9
    selection = [];
end

while total < 9
    x = randi(9);
    if state(x) == 0
        selection = x;
        total = total + 1;
        break
    end
end
end

function [x , y] = HW4P6_index_2_click_DOUGHERTY(abs_index)

if abs_index >= 7
    a = 3;
elseif abs_index >= 4
    a = 2;
else
    a = 1;
end

if mod(abs_index , 3) == 0
    b = 1;
elseif mod(abs_index , 3) == 2
    b = 2;
else
    b = 3;
end

x = a;
y = b;

end
