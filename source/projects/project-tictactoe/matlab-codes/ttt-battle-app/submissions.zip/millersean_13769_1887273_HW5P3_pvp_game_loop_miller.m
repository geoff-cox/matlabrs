function [game_state] = HW5P3_pvp_game_loop_miller(game_state)
%%Name:Sean Miller
%%Help Received:None
while game_state.round<=9
    [x,y]=HW4P7_get_valid_click_miller(game_state.data);
    abs_index=HW4P5_click_2_index_miller(x,y);
    game_state.x_click=x;
    game_state.y_click=y;
    game_state.data(abs_index)=game_state.player;
    HW4P4_update_board_miller(game_state)
    game_state.round=game_state.round+1;
    game_state.empty_space(abs_index)=false;
    game_state.player=game_state.player*-1;
    if game_state.player==1
        game_state.whos_turn='X';
    else
        game_state.whos_turn ='O';
    end
    if HW4P8_winner_check_miller(game_state.data)==1
        game_state.winner=1;
        title('X is Victorious, O, you suck!')
    elseif HW4P8_winner_check_miller(game_state.data)==-1
        game_state.winner=-1;
        title('O rose to the challenge, X is a failure!')
    else
        game_state.winner=0;
        title('You are both garbage, just a waste of your time and my time!')
    end

end
end