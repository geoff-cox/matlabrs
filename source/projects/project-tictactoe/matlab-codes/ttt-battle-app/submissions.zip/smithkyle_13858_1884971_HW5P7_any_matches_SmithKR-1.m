function [count] = HW5P7_any_matches_SmithKR(list1,list2);
p=length(list2);
i=1;
k=1;
count=0;
while i<=p
    k=1;
    while k<=p
        if list1(i)==list2(k)
            count=count+1;
            list2(k)=[];
            list1(i)=[];
            p=length(list2);
            k=p+1;
            i=i-1;
        else
            k=k+1;
        end
    end
    i=i+1;
end
