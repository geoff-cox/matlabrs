% Author: Jonathan Tumwikirize 
% Date: 15th November 2023
% HR: none
% 
% Description: This program implements the game loop for a PVP version of 
% the Tic-Tac-Toe game. Assume the X player is the first player, then the
% game loop should repeat at most nine-rounds of a Tic-Tac-Toe game. Each
% round should consist of the following tasks:
%       - Get a valid click from a single player
%       - Update the game_state structure
%       - Update the game interface
%       - Check for a winner!
%
function state = HW5P3_pvp_game_loop_Tumwikirize(state)
%
HW4P3_display_initial_board_Tumwikirize()
%
while state.round ~= 9 

    % Gets a valid click and returns its coordinates. 
    [x, y] =  HW4P7_get_valid_click_Tumwikirize(state);
    state.x_click = x;
    state.y_click = y;

    % Update other fields within state struct. 
    abs_index = HW4P5_click_2_index_Tumwikirize(x,y);
    state.empty_space(abs_index) = 0;
    state.data(abs_index) = state.player;
    state.round = state.round + 1;
     

    % Toggle betweeen who's turn it is. 
    if state.whos_turn == 'O'
        state.whos_turn = 'X';
    else 
        state.whos_turn = 'O';
    end

    % Update board
    HW4P4_update_board_Tumwikirize(state);

    % Display winner if there is one!
    state.winner = HW4P8_winner_check_Tumwikirize(state.data);

    if state.winner == 1
        disp('Winner, Winner, Chicken Dinner!')
        break;
    end

    % Toggle between players.
    if state.player == 1
        state.player = -1;
    else 
        state.player = 1;
    end

end
end


%% Initial Display Function
function HW4P3_display_initial_board_Tumwikirize()
%
%
f = figure
f.Position = [100, 200, 400, 600];
%
hold on 
grid on
axis([0.5 4.5 0.5 4.5])
axis equal
%
line([1 4], [2 2], 'LineWidth', 3, 'Color', 'Black')
line([1 4], [3 3], 'LineWidth', 3, 'Color', 'Black')
line([2 2], [1 4], 'LineWidth', 3, 'Color', 'Black')
line([3 3], [1 4], 'LineWidth', 3, 'Color', 'Black')
end

%% Update Board Function
function state = HW4P4_update_board_Tumwikirize(state)
%
if state.player == 1
    text(state.x_click + 0.2, ...
         state.y_click + 0.5, ...
        'X', 'FontSize', 50, ...
        'Color', 'b')
end

if state.player == -1
    text(state.x_click + 0.2, ...
         state.y_click + 0.5, ...
        'O', 'FontSize', 50, ...
        'Color', 'r')
end


end

% Get Valid Click Function
function [x,y] = HW4P7_get_valid_click_Tumwikirize(state)
%

% When mouse button pressed, take coordinates x and y

    [x_1,y_1] = ginput(1);

    
    %  Lies within the board region?
    if x_1 < 1 || x_1 > 4 
        disp('Invalid selection, try again')
    elseif y_1 < 1 || y_1 > 4 
        disp('Invalid selection, try again')
    end

   while 1 
        % Check if selected space is empty. Once clicked, space occupied.
        abs_index = HW4P5_click_2_index_Tumwikirize(x_1,y_1);
        if state.empty_space(abs_index) == 1
            disp('Valid Selection')
            x = floor(x_1); y = floor(y_1);
            break;
        else
            [x_1,y_1] = ginput(1);
            continue;
        end
    end
end


%% Click to index function
function abs_index = HW4P5_click_2_index_Tumwikirize(x,y)
%
% For quardants: 1. 2. 3. 
while x >= 1 && x < 2 
    if y < 2 && y >= 1 
        abs_index = 3;
        break;
    end

    if y <3 && y >=2
        abs_index = 2;
        break;
    end

    if y < 4 && y >= 3
        abs_index = 1;
        break;
    end
end

% For quadrants: 4. 5. 6. 
while x >= 2 && x < 3 
    if y < 2 && y >= 1 
        abs_index = 6;
        break;
    end

    if y <3 && y >=2
        abs_index = 5;
        break;
    end

    if y < 4 && y >= 3
        abs_index = 4;
        break;
    end
end

% For quadrants: 7. 8. 9. 
while x >= 3 && x < 4 
    if y < 2 && y >= 1 
        abs_index = 9;
        break;
    end

    if y <3 && y >=2
        abs_index = 8;
        break;
    end

    if y < 4 && y >= 3
        abs_index = 7;
        break;
    end
end
end

%% Check winner function
function result = HW4P8_winner_check_Tumwikirize(data)
%
sum_list = HW3P10_row_col_diag_sums_Tumwikirize(data);
%
for i = 1:length(sum_list)
    if abs(sum_list(i)) == 3
        result = 1;
        break;
    else
        result = 0;
    end
end
end

%% Sum list of rows, cols etc.
function sum_list = HW3P10_row_col_diag_sums_Tumwikirize(A)
%
% Initialize Values
[rows, cols] = size(A);
sum_list = [];

% Sum of Rows
for i = 1:rows 
    sum_list = [sum_list sum(A(i,:))];
end

% Sum of columns 
for i = 1:cols
    sum_list = [sum_list sum(A(:,i))];
end

% Diagnols
if rows < cols
    temp_sum_diag = 0;
    for i = 1:rows
       temp_sum_diag = temp_sum_diag + A(i,i);
    end
 
else 
    temp_sum_diag = 0;
    for i = 1:cols
       temp_sum_diag = temp_sum_diag + A(i,i);
    end
end
sum_list = [sum_list temp_sum_diag];

    
% Anti-Diagnol 
temp_sum_adiag = 0;
temp_sol = rows + 1;
for i = 1:rows
    for k = 1:cols
        if (i + k)  == temp_sol
            temp_sum_adiag = temp_sum_adiag + A(i,k);
        end
    end
end
sum_list = [sum_list temp_sum_adiag];
end


