%hr:in class help
%mack,DL
function state = Hw5P4_pve_game_loop_mack(state,ai_O_level)
%is the ai level going to be dermined in the struct
for k=1:9
    state.round=k;
    x=0;
    y=0;
    if state.whos_turn=='x'|| state.whos_turn=='X'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
         Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(1,abs_index)=0; 
        state.data(abs_index)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
%
   
    end
    if state.whos_turn=='o'||state.whos_turn=='O'
        
        if ai_O_level == '1'
            selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '2'
            selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '3'
            selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
            

            
    end

end