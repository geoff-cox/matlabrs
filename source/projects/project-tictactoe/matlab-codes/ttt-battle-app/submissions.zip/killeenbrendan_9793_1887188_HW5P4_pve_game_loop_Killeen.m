% Brendan Killeen
% HR: none

%%
function [game_state] = HW5P4_pve_game_loop_Killeen(game_state, ai_O_level)

round_counter = 0;                  % establish round counter

while game_state.winner == 0

    round_counter = round_counter + 1;    % start a new round

    [x,y] = HW4P7_get_valid_click_Killeen(game_state);  % X's turn
    abs_index = HW4P5_click_2_index_Killeen(x,y);

    game_state.data(abs_index) = 1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'X';
    game_state.player = 1;
    game_state.empty_space(abs_index) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);

    result = HW4P8_winner_check_Killeen(game_state.data);
    game_state.winner = result;

    if game_state.winner ~= 0
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end

    pause(0.5);

    % FLIP TO THE AI TAKEOVER

    game_state.player = -1;             % change player

    if ai_O_level == '1'
        selection = HW4P9_dumb_ai_move_Killeen(game_state);
        % WILL ADD OTHER DIFFICULTIES AS THEY GET WRITTEN
    elseif ai_O_level == '2'
        selection = HW5P1_better_ai_move_Killeen(game_state);

    %elseif ai_O_level == '3'
        %ai_selection = HW5P2_my_ai_move_Killeen(game_state);

    end

    [x,y] = HW4P6_index_2_click_Killeen(selection);

    game_state.data(selection) = -1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'O';
    game_state.empty_space(selection) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);

    result = HW4P8_winner_check_Killeen(game_state.data);
    game_state.winner = result;

    if game_state.winner ~= 0
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end


end

end

%% HELPER FUNCTIONS

% Valid Click
function [x,y] = HW4P7_get_valid_click_Killeen(game_state)

valid = false;                  % initialize while loop

while valid == false

    click = ginput(1);
    x_test = floor(click(1));
    y_test = floor(click(2));

    if x_test >= 4 || y_test >= 4
        continue
    elseif x_test < 1 || y_test < 1
        continue
    end

    abs_index = HW4P5_click_2_index_Killeen(x_test,y_test);

    if game_state.empty_space(abs_index) == 1
        x = x_test;
        y = y_test;
        valid = true;
    end
    
end

end

% Click to Index
function [abs_index] = HW4P5_click_2_index_Killeen(x,y)

index = [3, 6, 9;...
         2, 5, 8;...
         1, 4, 7];

abs_index = index(y,x)

end

% Index to Click
function [x,y] = HW4P6_index_2_click_Killeen(abs_index)

x_coords = [1, 2, 3;...
            1, 2, 3;...
            1, 2, 3];

y_coords = [3, 3, 3;...
            2, 2, 2;...
            1, 1, 1];

x = x_coords(abs_index)
y = y_coords(abs_index)

end

% Update the Board
function [] = HW4P4_update_board_Killeen(game_state)

x = game_state.x_click;
y = game_state.y_click;

if game_state.player == -1
    text(x+0.2, y+0.53, 'O', 'color', 'blue', 'FontSize', 50)

elseif game_state.player == 1
    text(x+0.25, y+0.5, 'X', 'color', 'red', 'FontSize', 50)

end

end

% Check for Winner
function [result] = HW4P8_winner_check_Killeen(data)

sums = HW3P10_row_col_diag_sums_Killeen(data);

% if any of the sums are 3 or -3, then winner is 1 or -1, otherwise it
% returns 0

result = 0;             % initialize result

for idx = 1:length(sums)

    if sums(idx) == 3
        result = 1;
        break

    elseif sums(idx) == -3
        result = -1;
        break
    end

end

end

% Row/Column/Diagonal Sums
function [sum_list] = HW3P10_row_col_diag_sums_Killeen(A)

[m, n] = size(A);           % store dimensions of A

for i = 1:m
    row = A(i,:);           % set up temporary row vector
    row_sum(i) = sum(row);  % sum temporary row, store in vector
end

% TRANSPOSE THESE FUNCTIONS WHEN INSERTING INTO SUM LIST

for j = 1:n
    col = A(:,j);           % set up temp column vector
    col_sum(j) = sum(col);  % sum temporary column, store in vector
end

% REFERENCE SMALLEST DIMENSION AS INDEX FOR DIAGONALS
if m <= n
    least = m;              % establishing which dimension is smaller
else
    least = n;
end


for idx = 1:least
    diagonal(idx) = A(idx,idx);  % take the diagonal

end

row_count = m;
count = 1;                       % establish a counter to reference column
for jdx = least:-1:1
        antidiag(count) = A(row_count,count);    % for every loop, A(least-1,count+1)
        row_count = row_count - 1;
        count = count + 1;
end


diag_sum = sum(diagonal);
anti_sum = sum(antidiag);

sum_list = [row_sum';col_sum';diag_sum';anti_sum'];

end

% Dumb AI

% Better AI

% My AI Strategy

