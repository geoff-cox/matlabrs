function game_state = pve_game_loop_kohan(game_state)

result = HW4P8_winner_check_kohan(game_state.data);
k = 1;
answer = questdlg('Select Difficulty Level',...
    'Difficulty Level',...
    'Easy', 'Medium','Hard','Hard');
switch answer
    case 'Easy'
        while result == 0
            % loop for AI turn
            if game_state.player == -1 && game_state.whos_turn == 'O'
                disp(game_state.data)
                selection = HW4P9_dumb_ai_move_kohan(game_state);
                [x,y] = HW4P6_index_2_click_kohan(selection);
                game_state.x_click = x;
                game_state.y_click = y;
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                game_state.empty_space(selection) = false;
                game_state.data(selection) = -1;
                game_state.player = game_state.player*-1;
                if game_state.player == 1
                game_state.whos_turn = 'X';
                elseif game_state.player == -1
                game_state.whos_turn = 'O';
                end
                if HW4P8_winner_check_kohan(game_state.data) == 1
                game_state.winner = 1;
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                game_state.winner = -1;
                end
                l = length(game_state.empty_space);
                    for k = l
                        if game_state.empty_space(k) == 0
                            game_state.empty_space(k) = [];
                            l = length(game_state.empty_space);
                        end
                    end
                % after the AI plays you have to ensure player is 1
            elseif game_state.player == 1 && game_state.whos_turn == 'X'
                % get the click of the player and update data matrix
                [x,y] = HW4P7_get_valid_click_kohan(game_state);
                abs_index = HW4P5_click_2_index_kohan(x,y);
                game_state.x_click = x;
                game_state.y_click = y;
                game_state.data(abs_index) = game_state.player;
                % actually plot the click
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                % update empty spaces
                game_state.empty_space(abs_index) = false;
                % then check to see if that was a winning move
                result = HW4P8_winner_check_kohan(game_state.data);
                % change the player to the opposite player
                game_state.player = game_state.player*-1;
                % update who's turn
                if game_state.player == 1
                    game_state.whos_turn = 'X';
                elseif game_state.player == -1
                    game_state.whos_turn = 'O';
                end
                % after human plays, ensure player = -1
                if HW4P8_winner_check_kohan(game_state.data) == 1
                    game_state.winner = 1;
                    title('Player X Wins!')
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                    game_state.winner = -1;
                    title('Player O Wins!')
                end
                display(game_state)
            end
        end
    case 'Medium'
        while result == 0
            % loop for AI turn
            if game_state.player == -1 && game_state.whos_turn == 'O'
                selection = HW5P1_better_ai_move_kohan(game_state);
                % deny the code and AI from being able to choose the same spot over and
                % over, that is the current problem
                [x,y] = HW4P6_index_2_click_kohan(selection);
                game_state.x_click = x;
                game_state.y_click = y;
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                game_state.empty_space(selection) = false;
                game_state.data(selection) = -1;
                game_state.player = game_state.player*-1;
                if game_state.player == 1
                game_state.whos_turn = 'X';
                elseif game_state.player == -1
                game_state.whos_turn = 'O';
                end
                if HW4P8_winner_check_kohan(game_state.data) == 1
                game_state.winner = 1;
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                game_state.winner = -1;
                end
                l = length(game_state.empty_space);
                    for k = l
                        if game_state.empty_space(k) == 0
                            game_state.empty_space(k) = [];
                            l = length(game_state.empty_space);
                        end
                    end
                % after the AI plays you have to ensure player is 1
            elseif game_state.player == 1 && game_state.whos_turn == 'X'
                % get the click of the player and update data matrix
                [x,y] = HW4P7_get_valid_click_kohan(game_state);
                abs_index = HW4P5_click_2_index_kohan(x,y);
                game_state.x_click = x;
                game_state.y_click = y;
                game_state.data(abs_index) = game_state.player;
                % actually plot the click
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                % update empty spaces
                game_state.empty_space(abs_index) = false;
                % then check to see if that was a winning move
                result = HW4P8_winner_check_kohan(game_state.data);
                % change the player to the opposite player
                game_state.player = game_state.player*-1;
                % update who's turn
                if game_state.player == 1
                    game_state.whos_turn = 'X';
                elseif game_state.player == -1
                    game_state.whos_turn = 'O';
                end
                % after human plays, ensure player = -1
                if HW4P8_winner_check_kohan(game_state.data) == 1
                    game_state.winner = 1;
                    title('Player X Wins!')
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                    game_state.winner = -1;
                    title('Player O Wins!')
                end
                display(game_state)
            end
        end
    case 'Hard'
        while result == 0
            % loop for AI turn
            if game_state.player == -1 && game_state.whos_turn == 'O'
                selection = HW5P2_my_ai_move_kohan(game_state);
                % deny the code and AI from being able to choose the same spot over and
                % over, that is the current problem
                [x,y] = HW4P6_index_2_click_kohan(selection);
                game_state.x_click = x;
                game_state.y_click = y;
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                game_state.empty_space(selection) = false;
                game_state.data(selection) = -1;
                game_state.player = game_state.player*-1;
                if game_state.player == 1
                game_state.whos_turn = 'X';
                elseif game_state.player == -1
                game_state.whos_turn = 'O';
                end
                if HW4P8_winner_check_kohan(game_state.data) == 1
                game_state.winner = 1;
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                game_state.winner = -1;
                end
                l = length(game_state.empty_space);
                    for k = l
                        if game_state.empty_space(k) == 0
                            game_state.empty_space(k) = [];
                            l = length(game_state.empty_space);
                        end
                    end
                % after the AI plays you have to ensure player is 1
            elseif game_state.player == 1 && game_state.whos_turn == 'X'
                % get the click of the player and update data matrix
                [x,y] = HW4P7_get_valid_click_kohan(game_state);
                abs_index = HW4P5_click_2_index_kohan(x,y);
                game_state.x_click = x;
                game_state.y_click = y;
                game_state.data(abs_index) = game_state.player;
                % actually plot the click
                HW4P4_update_board_kohan(game_state);
                game_state.round = game_state.round + 1;
                % update empty spaces
                game_state.empty_space(abs_index) = false;
                % then check to see if that was a winning move
                result = HW4P8_winner_check_kohan(game_state.data);
                % change the player to the opposite player
                game_state.player = game_state.player*-1;
                % update who's turn
                if game_state.player == 1
                    game_state.whos_turn = 'X';
                elseif game_state.player == -1
                    game_state.whos_turn = 'O';
                end
                % after human plays, ensure player = -1
                if HW4P8_winner_check_kohan(game_state.data) == 1
                    game_state.winner = 1;
                    title('Player X Wins!')
                elseif HW4P8_winner_check_kohan(game_state.data) == -1
                    game_state.winner = -1;
                    title('Player O Wins!')
                end
                display(game_state)
            end
        end
end
end