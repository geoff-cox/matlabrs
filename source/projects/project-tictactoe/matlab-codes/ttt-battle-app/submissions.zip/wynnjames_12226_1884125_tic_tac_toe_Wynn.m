% Close all figures
clc
close all

% Creates initial game setup
game_state.data = zeros(3,3);
game_state.round = 0;
game_state.winner = 0;
game_state.whos_turn = 'X';
game_state.player = 1;
game_state.empty_space = true(1,9);
game_state.x_click = 0;
game_state.y_click = 0;

% Select game type
fprintf('PvP = 1 \n')
fprintf('PvE = 2 \n')
fprintf('EvE = 3 \n')
game = input('Select what type of game to play: \n');

if game == 1

    HW4P3_display_initial_board_Wynn
    game_state = HW5P3_pvp_game_loop_Wynn(game_state)

elseif game == 2

    fprintf('dumb_ai_move = 1 \n')
    fprintf('better_ai_move = 2 \n')
    fprintf('my_ai_move = 3 \n')
    O_level = input('Select AI level: \n');
    game_state.ai_O_level = O_level;

    HW4P3_display_initial_board_Wynn
    game_state = HW5P4_pve_game_loop_Wynn(game_state)

elseif game == 3

    fprintf('dumb_ai_move = 1 \n')
    fprintf('better_ai_move = 2 \n')
    fprintf('my_ai_move = 3 \n')
    X_level = input('Select X-AI level: \n');
    O_level = input('Select O-AI level: \n');

    game_state.ai_X_level = X_level;
    game_state.ai_O_level = O_level;

    HW4P3_display_initial_board_Wynn
    game_state = HW5P5_eve_game_loop_Wynn(game_state)

else

    fprintf('Input not available.')

end

% =========================================================================
% HW 5 P 1
% Returns an AI move on available ttt space focussed on winning

function index = HW5P1_better_ai_move_Wynn(game_state)

    data = game_state.data;
    play = game_state.player;

    for k = 1:9

        temp_data = data;
        
        if data(k) == 0

            temp_data(k) = play;
            win = HW4P8_winner_check_Wynn(temp_data);
    
            if win == play
    
                index = k;
                return
    
            end
        end
    end

    for j = 1:9

        temp_data = data;
        
        if data(j) == 0

            temp_data(j) = play * -1;
            win = HW4P8_winner_check_Wynn(temp_data);
    
            if win == play * -1
    
                index = j;
                return
    
            end
        end
    end

    index = HW4P9_dumb_ai_move_Wynn(game_state);
end

% =========================================================================
% HW 5 P 2
% Strategically returns an AI move on available ttt space

function index = HW5P2_my_ai_move_Wynn(game_state)

    data = game_state.data;
    play = game_state.player;

    for k = 1:9

        temp_data = data;
        
        if data(k) == 0

            temp_data(k) = play;
            win = HW4P8_winner_check_Wynn(temp_data);
    
            if win == play
    
                index = k;
                return
    
            end
        end
    end

    mi = data(2,2) * play;
    tl = data(1,1) * play;
    tr = data(1,3) * play;
    bl = data(3,1) * play;
    br = data(3,3) * play;

    if mi == 0

        index = 5;
        return

    elseif tl >= 0 && tr >= 0 && bl >= 0

        if data(1) == 0
        
            index = 1;
            return
        end

    elseif tl >= 0 && tr >= 0 && br >= 0

        if data(7) == 0

            index = 7;
            return  
        end

    elseif tl >= 0 && bl >= 0 && br >= 0

        if data(3) == 0

            index = 3;
            return
        end

    elseif tr >= 0 && br >= 0 && bl >= 0

        if data(9) == 0

            index = 9;
            return
        end
    end

    for j = 1:9

        temp_data = data;
        
        if data(j) == 0

            temp_data(j) = play * -1;
            win = HW4P8_winner_check_Wynn(temp_data);
    
            if win == play * -1
    
                index = j;
                return
    
            end
        end
    end

    index = HW4P9_dumb_ai_move_Wynn(game_state);
end

% =========================================================================
% HW 5 P 3
% Player v Player game loop

function game_state = HW5P3_pvp_game_loop_Wynn(game_state)

    while game_state.round < 9

        [x_click, y_click] = HW4P7_get_valid_click_Wynn(game_state);
        game_state.x_click = x_click;
        game_state.y_click = y_click;

        index = HW4P5_click_2_index_Wynn(x_click,y_click);
        game_state.empty_space(index) = false;
        game_state.data(index) = game_state.player;
        game_state.round = game_state.round + 1;

        HW4P4_update_board_Wynn(game_state);

        win = HW4P8_winner_check_Wynn(game_state.data);

        if game_state.player == 1

            game_state.whos_turn = 'X';

        elseif game_state.player == -1

            game_state.whos_turn = 'O';

        end

        if win ~= 0

            game_state.winner = game_state.player;
            return

        end
    
        game_state.player = game_state.player * -1;

    end
end

% =========================================================================
% HW 5 P 4
% Player v Enemy game loop

function game_state = HW5P4_pve_game_loop_Wynn(game_state)

    if game_state.ai_O_level == 1

        ai = @HW4P9_dumb_ai_move_Wynn;

    elseif game_state.ai_O_level == 2

        ai = @HW5P1_better_ai_move_Wynn;

    elseif game_state.ai_O_level == 3

        ai = @HW5P2_my_ai_move_Wynn;

    end


    while game_state.round < 9

        if game_state.player == 1

            [x_click, y_click] = HW4P7_get_valid_click_Wynn(game_state);
            game_state.x_click = x_click;
            game_state.y_click = y_click;
    
            index = HW4P5_click_2_index_Wynn(x_click,y_click);

        elseif game_state.player == -1

            index = ai(game_state);
            [x_click, y_click] = HW4P6_index_2_click_Wynn(index);
            game_state.x_click = x_click;
            game_state.y_click = y_click;

        end

        game_state.empty_space(index) = false;
        game_state.data(index) = game_state.player;

        HW4P4_update_board_Wynn(game_state);
        game_state.round = game_state.round + 1;

        win = HW4P8_winner_check_Wynn(game_state.data);

        if game_state.player == 1

            game_state.whos_turn = 'X';

        elseif game_state.player == -1

            game_state.whos_turn = 'O';

        end

        if win ~= 0

            game_state.winner = game_state.player;
            return

        end
    
        game_state.player = game_state.player * -1;

    end
end

% =========================================================================
% HW 5 P 5
% Player v Enemy game loop

function game_state = HW5P5_eve_game_loop_Wynn(game_state)

    if game_state.ai_X_level == 1

        ai_X = @HW4P9_dumb_ai_move_Wynn;

    elseif game_state.ai_X_level == 2

        ai_X = @HW5P1_better_ai_move_Wynn;

    elseif game_state.ai_X_level == 3

        ai_X = @HW5P2_my_ai_move_Wynn;

    end

    if game_state.ai_O_level == 1

        ai_O = @HW4P9_dumb_ai_move_Wynn;

    elseif game_state.ai_O_level == 2

        ai_O = @HW5P1_better_ai_move_Wynn;

    elseif game_state.ai_O_level == 3

        ai_O = @HW5P2_my_ai_move_Wynn;

    end


    while game_state.round < 9

        if game_state.player == 1

            index = ai_X(game_state);
            [x_click, y_click] = HW4P6_index_2_click_Wynn(index);
            game_state.x_click = x_click;
            game_state.y_click = y_click;

        elseif game_state.player == -1

            index = ai_O(game_state);
            [x_click, y_click] = HW4P6_index_2_click_Wynn(index);
            game_state.x_click = x_click;
            game_state.y_click = y_click;

        end

        game_state.empty_space(index) = false;
        game_state.data(index) = game_state.player;

        HW4P4_update_board_Wynn(game_state);
        game_state.round = game_state.round + 1;

        win = HW4P8_winner_check_Wynn(game_state.data);

        if game_state.player == 1

            game_state.whos_turn = 'X';

        elseif game_state.player == -1

            game_state.whos_turn = 'O';

        end

        if win ~= 0

            game_state.winner = game_state.player;
            return

        end
    
        game_state.player = game_state.player * -1;

    end
end

% =========================================================================
% HW 4 P 4
% Plots X or O in a given space on the board

function HW4P4_update_board_Wynn(game_state)

    x = game_state.x_click;
    y = game_state.y_click;

    if game_state.player == 1

        x = x + .15;
        y = y + .55;
        text(x,y,'X', 'Color','blue','FontSize',90)

    elseif game_state.player == -1

        x = x + .1;
        y = y + .55;
        text(x,y,'O', 'Color','red','FontSize',90)

    end
end

% =========================================================================
% HW 4 P 5
% Produces absolute indexing based on coordinates

function abs_index = HW4P5_click_2_index_Wynn(x,y)

    A = [3 2 1 ; 6 5 4; 9 8 7];

    abs_index = A(x,y);

end

% =========================================================================
% HW 4 P 6
% Produces coordinates based on absolute indexing

function [x, y] = HW4P6_index_2_click_Wynn(k)
% [x, y] = HW4P6_index_2_click_Wynn()

    A = [3 2 1 ; 6 5 4; 9 8 7];

    for i = 1:3
        for j = 1:3
            if A(i,j) == k
                x = i;
                y = j;
            end
        end
    end
    
end

% =========================================================================
% HW 4 P 7
% Returns a valid click from ttt player

function [x_click, y_click] = HW4P7_get_valid_click_Wynn(game_state)

    n = 0;
    v = 0;

    while n < 1

        [xc, yc] = ginput(1);
        x_click = floor(xc);
        y_click = floor(yc);

        if x_click > 3 || x_click < 1 || y_click > 3 || y_click < 1
            

        else

            i = HW4P5_click_2_index_Wynn(x_click,y_click);
            v = game_state.empty_space(i);

        end

        if v == 1

            n = 1;

        else

            n = 0;

        end
    end
end

% =========================================================================
% HW 4 P 8
% Returns ttt winner

function result = HW4P8_winner_check_Wynn(data)

    diag_sum = sum(data(1,1) + data(2,2) + data(3,3));
    adiag_sum = sum(data(3,1) + data(2,2) + data(1,3));

    for i = 1:3
    
        col_sum = sum(data(i,:));
        row_sum = sum(data(:,i));
    
        if col_sum == 3 || row_sum == 3 || diag_sum == 3 || adiag_sum == 3
    
            result = 1;
            return
    
        elseif col_sum == -3 || row_sum == -3 || diag_sum == -3 || adiag_sum == -3
    
            result = -1;
            return
    
        else
    
            result = 0;
    
        end
    end
end

% =========================================================================
% HW 4 P 9
% Returns an AI move on available ttt space with equal probability

function index = HW4P9_dumb_ai_move_Wynn(game_state)

    n = 0;

    matrix = game_state.data;
    spaces = game_state.empty_space;

    for k = 1:10
    
        if k == 10

            index = [];
            return

        elseif spaces(k) == 1

            while n ~= 1

                index = randi(9);
                valid = matrix(index);
                
                if valid == 0
        
                    n = 1;
                    return 
        
                else
        
                    n = 0;
        
                end
            end
        end
    end
end