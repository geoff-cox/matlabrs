function selection = HW5P1_better_ai_move_kohan(game_state)

    for k = 1:9
        % check for winning move, take if found
            if game_state.data(k) == 0
                check = game_state.data;
                check(k) = game_state.player-2;
                if HW4P8_winner_check_kohan(check) == -1
                    selection = k;
                    return
                end
            end
    end
    for k = 1:9
            % check for blocking move, take if found
            if game_state.data(k) == 0
                check = game_state.data;
                check(k) = game_state.player;
                if HW4P8_winner_check_kohan(check) == 1
                    selection = k;
                    return
                end
            end    
    end
    for k = 1:9
        % if there is not move that blocks a win or wins, choose random
        if game_state.data(k) == 0
            check = game_state.data;
            check(k) = game_state.player-2;
            if HW4P8_winner_check_kohan(check) == 0
                selection = HW4P9_dumb_ai_move_kohan(check);
            end
        end
    end
end