%hr:in class help
%mack,DL
function selection = Hw5P2_my_ai_move_mack(state)
selection=0;
if state.player == -1 
    if state.empty_space(5)==1
        selection = 5;
        return
    end
    
end
if state.player == -1 
    l=length(state.empty_space);
selection = 0;
orig=state.data;
tst=state.data;
    
        for k=1:l
            if state.empty_space(k)==1
                tst(k)=1;
                result = Hw4P8_winner_check_mack(tst);
                if result==1
                    selection =k;
                    return
                else
                    tst=orig;
                end
            end
        end
        for k=1:l
            if state.empty_space(k)==1           
                tst(k)=-1;
                result = Hw4P8_winner_check_mack(tst);
                if result == -1
                    selection =k;
                    return
                else
                    tst=orig;
                end
            end
        end
        if selection == 0
            if state.empty_space(1)==1
                selection = 1;
                return
            end
            if state.empty_space(3)==1
                selection = 3;
                return
            end
            if state.empty_space(7)==1
                selection = 7;
                return
            end
            if state.empty_space(9)==1
                selection = 9;
                return
            end
        end
    end
    



Hw4P4_update_board_mack(state)
end

