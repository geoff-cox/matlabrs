%hr:in class help
%mack,DL
function state = Hw5P5_eve_loop_mack(state,ai_X_level,ai_O_level)
for k=1:9
    x=0;
    y=0;
    if state.player == 1
    if ai_X_level == '1'
        selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    if ai_X_level == '2'
        selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    if ai_X_level == '3'
        selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    end
    if state.player == -1 
        if ai_O_level =='1' 
            selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '2'
            selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '3'
            selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
    end


end