%hr:in class help
%mack,DL
function state = Hw5P3_pvp_game_loop_mack(state)
for k=1:9
    state.round=k;
    if state.whos_turn=='x'|| state.whos_turn=='X'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
         Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(abs_index)=0; 
        state.data(abs_index)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
%
   
    end
    if state.whos_turn=='o'||state.whos_turn=='O'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(abs_index)=0;
        
        state.data(abs_index)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
    end
end
end
function [x, y] = Hw4P7_get_valid_click_mack(game_state)
x=0;
y=0;
c=0;
while c==0
k = ginput(1);
    if 1 <= k(1) && k(1) < 4 && k(2) >= 1 && k(2) < 4
        W = floor(k(1));
        Z = floor(k(2));
        abs_index = Hw4P5_click_2_index_mack(W,Z);
        if game_state.empty_space(1,abs_index) == 1
        x = floor(k(1));
        y = floor(k(2));
        c=1;
        end
   
    end
end
end
