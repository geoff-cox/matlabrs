%HW5P3_pvp_game_loop_smithc
function game_state=HW5P3_pvp_game_loop_smithc(game_state)
for i=1:9
if i==1 || i==3|| i==5|| i==7|| i==9
    game_state.whos_turn='X'
    game_state.player=1
else
    game_state.whos_turn='O'
    game_state.player=-1
end
[game_state.x_click, game_state.y_click]=HW4P7_get_valid_click_smithc(game_state) 
if game_state.whos_turn=='X'
    A=HW4P5_click_2_index_smithc(game_state.x_click,game_state.y_click)
    game_state.data(A)=1
else 
    A=HW4P5_click_2_index_smithc(game_state.x_click,game_state.y_click)
    game_state.data(A)=-1
end 
game_state.empty_space(A)=0
HW4P4_update_board_smithc(game_state)
W=HW4P8_winner_check_smithc(game_state.data)
if W==-1 && game_state.player==-1
    game_state.winner=-1
elseif W==1 && game_state.player==1
    game_state.winner=1
else
    game_state.winner=0
end

if game_state.winner== 1||game_state.winner==-1
      return 
end

end
game_state=game_state
end 

 




%HW4P7_get_valid_click_smithc
function [x_click,y_click]=HW4P7_get_valid_click_smithc(game_state)
i=1;
while i<2
G=ginput(1);
Xx=floor(G(1));
Yy=floor(G(2));

    if Xx<=4 && Yy<=4 && Xx>= 1 && Yy>=1
        x_click=Xx;
        y_click=Yy;
        i=i+1;
        A=HW4P5_click_2_index_smithc(Xx,Yy);
        if game_state.empty_space(A)==0 
            i=1;
        end
        
    
    else
        i=1;
    end
  
end
end

%HW4P4_update_board_smithc

function  HW4P4_update_board_smithc(game_state)
game_state.x_click=floor(game_state.x_click);
game_state.y_click=floor(game_state.y_click);
xxcord=game_state.x_click+.24;
xycord=game_state.y_click+.55;
oxcord=game_state.x_click+.16;
oycord=game_state.y_click+.5;
if game_state.whos_turn=='X'
    
   text(xxcord, xycord,'X', 'FontSize', 100)
    
else 
    text(oxcord, oycord,  'O', 'FontSize',100)
    
end
end


%HW4P8_winner_check_smithc
function result=HW4P8_winner_check_smithc(data)
M=data
if M(1)==1 && M(4)==1 && M(7)==1
    result=1; 
elseif M(2)==1 && M(5)==1 && M(8)==1
    result=1;
elseif M(3)==1 && M(6)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(2)==1 && M(3)==1
    result=1;
elseif M(4)==1 && M(5)==1 && M(6)==1
    result=1;
elseif M(7)==1 && M(8)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(5)==1 && M(9)==1
    result=1;
elseif M(7)==1 && M(5)==1 && M(3)==1
    result=1;
elseif M(1)==-1 && M(4)==-1 && M(7)==-1
    result=-1;
elseif M(2)==-1 && M(5)==-1 && M(8)==-1
    result=-1;
elseif M(3)==-1 && M(6)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(2)==-1 && M(3)==-1
    result=-1;
elseif M(4)==-1 && M(5)==-1 && M(6)==-1
    result=-1;
elseif M(7)==-1 && M(8)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(5)==-1 && M(9)==-1
    result=-1;
elseif M(7)==-1 && M(5)==-1 && M(3)==-1
    result=-1;
else 
    
    result=0;
end
end 

%HW4P5_click_2_index_smithc
function abs_index=HW4P5_click_2_index_smithc(x_click,y_click)
M=[3,6,9;
   2,5,8;
   1,4,7];
abs_index=M(y_click,x_click);
end
