function game_state = pvp_game_loop_kohan(game_state)

result = HW4P8_winner_check_kohan(game_state.data);

    while result == 0
        % get the click of the player and update data matrix
        [x,y] = HW4P7_get_valid_click_kohan(game_state);
        abs_index = HW4P5_click_2_index_kohan(x,y);
        game_state.x_click = x;
        game_state.y_click = y;
        game_state.data(abs_index) = game_state.player;
        % actually plot the click, idk how you forgot that the first time
        HW4P4_update_board_kohan(game_state);
        game_state.round = game_state.round + 1;
        % update empty spaces
        game_state.empty_space(abs_index) = false;
        % then check to see if that was a winning move
        result = HW4P8_winner_check_kohan(game_state.data);
        % change the player to the opposite player
        game_state.player = game_state.player*-1;
        % update who's turn
        if game_state.player == 1
            game_state.whos_turn = 'X';
        elseif game_state.player == -1
            game_state.whos_turn = 'O';
        end
        if HW4P8_winner_check_kohan(game_state.data) == 1
            game_state.winner = 1;
            title('Player X Wins')
        elseif HW4P8_winner_check_kohan(game_state.data) == -1
            game_state.winner = -1;
            title('Player O Wins')
        elseif HW4P8_winner_check_kohan(game_state.data) == 0 && game_state.round == 9
            game_state.winner = 0;
            title('Draw')
            return
        end
        display(game_state)
    end
end