function game_state = eve_game_loop_kohan(game_state)

result = HW4P8_winner_check_kohan(game_state.data);

    while result == 0
        if game_state.player == -1 && game_state.whos_turn == 'O'
            selection = HW5P2_my_ai_move_kohan(game_state);
            [x,y] = HW4P6_index_2_click_kohan(selection);
            game_state.x_click = x;
            game_state.y_click = y;
            HW4P4_update_board_kohan(game_state);
            game_state.round = game_state.round + 1;
            game_state.empty_space(selection) = false;
            game_state.data(selection) = -1;
            game_state.player = game_state.player*-1;
            if game_state.player == 1
            game_state.whos_turn = 'X';
            elseif game_state.player == -1
            game_state.whos_turn = 'O';
            end
            if HW4P8_winner_check_kohan(game_state.data) == 1
            game_state.winner = 1;
            elseif HW4P8_winner_check_kohan(game_state.data) == -1
            game_state.winner = -1;
            end
            l = length(game_state.empty_space);
                for k = l
                    if game_state.empty_space(k) == 0
                        game_state.empty_space(k) = [];
                        l = length(game_state.empty_space);
                    end
                end
            % after the AI plays you have to ensure player is 1
        end
        if game_state.player == 1 && game_state.whos_turn == 'X'
            selection = HW5P2_my_ai_move_kohan(game_state);
            [x,y] = HW4P6_index_2_click_kohan(selection);
            game_state.x_click = x;
            game_state.y_click = y;
            HW4P4_update_board_kohan(game_state);
            game_state.round = game_state.round + 1;
            game_state.empty_space(selection) = false;
            game_state.data(selection) = -1;
            game_state.player = game_state.player*-1;
            if game_state.player == 1
            game_state.whos_turn = 'X';
            elseif game_state.player == -1
            game_state.whos_turn = 'O';
            end
            if HW4P8_winner_check_kohan(game_state.data) == 1
            game_state.winner = 1;
            elseif HW4P8_winner_check_kohan(game_state.data) == -1
            game_state.winner = -1;
            end
            l = length(game_state.empty_space);
                for k = l
                    if game_state.empty_space(k) == 0
                        game_state.empty_space(k) = [];
                        l = length(game_state.empty_space);
                    end
                end
            % after the AI plays you have to ensure player is -1
        end
         if HW4P8_winner_check_kohan(game_state.data) == 1
            game_state.winner = 1;
            title('Player X Wins!')
        elseif HW4P8_winner_check_kohan(game_state.data) == -1
            game_state.winner = -1;
            title('Player O Wins!')
        end
        display(game_state)
    end
end
        