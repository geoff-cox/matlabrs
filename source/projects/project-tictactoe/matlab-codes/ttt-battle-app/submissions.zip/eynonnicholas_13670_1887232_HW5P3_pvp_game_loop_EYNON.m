function [game_state] = HW5P3_pvp_game_loop_EYNON(game_state)

    while game_state.winner == 0
        game_state.round = game_state.round + 1;
        if game_state.round > 9
            game_state.winner = 0;
            break
    elseif mod(game_state.round,2) == 1
            game_state.whos_turn = 'X';
            [x,y] = HW4P7_get_valid_click_EYNON(game_state);
            game_state.x_click = x;
            game_state.y_click = y;
            [abs_index] = HW4P5_click_2_index_EYNON(x,y);
            game_state.data(x,y) = 1; 
            game_state.empty_space(abs_index) = 0;
            HW4P4_update_board_EYNON(game_state)
            [result] = HW4P8_winner_check_EYNON(game_state.data);
            game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        else 
            game_state.whos_turn = 'O';
            [x,y] = HW4P7_get_valid_click_EYNON(game_state);
            game_state.x_click = x;
            game_state.y_click = y;
            [abs_index] = HW4P5_click_2_index_EYNON(x,y);
            game_state.data(x,y) = -1; 
            game_state.empty_space(abs_index) = 0;
            HW4P4_update_board_EYNON(game_state)
            [result] = HW4P8_winner_check_EYNON(game_state.data);
            game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        end
    end
end