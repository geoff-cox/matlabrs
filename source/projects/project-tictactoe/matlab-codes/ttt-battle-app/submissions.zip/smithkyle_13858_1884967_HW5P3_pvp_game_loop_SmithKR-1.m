function [game_state] = HW5P3_pvp_game_loop_SmithKR(game_state);
i=1;
game_state.winner=0;
while i<=9
if game_state.winner==0
    [game_state.x_click,game_state.y_click]=HW4P7_get_valid_click_SmithKR(game_state);
    index(i)=HW4P5_click_2_index_SmithKR(game_state.x_click,game_state.y_click);
    game_state.empty_space(index(i))=false;
    HW4P4_update_board_SmithKR(game_state);
    if game_state.player==1
        game_state.data(index(i))=1;
        game_state.player=-1;
        game_state.whos_turn='O';
        game_state.round=i;
    else
        game_state.data(index(i))=-1;
        game_state.player=1;
        game_state.whos_turn='X';
        game_state.round=i;
    end
end
game_state.winner=HW4P8_winner_check_SmithKR(game_state.data);
i=i+1;
end
end

function result=HW4P8_winner_check_SmithKR(data);
wakawaka=HW3P10_row_col_diag_sums_SmithKR(data);
i=1;
result=0;
while i<=8
    if wakawaka(i) == 3
        result=1;
        i=100;
    elseif wakawaka(i) == -3
        result=-1;
        i=100;
    else
        i=i+1;
    end
end

end

function [sum_list] = HW3P10_row_col_diag_sums_SmithKR(A);
i=1;
w=width(A);
h=height(A);
k=1;
while k==1
    if i<=h
        sum_row(i)=sum(A(i,:));
    end
    if i<=w
        sum_column(i)=sum(A(:,i));
    end
    if w>=i && h>=i
        diagonal(i)=A(i,i);
    end
    if h-i>=0 && w>=i
        pp=h-(i-1);
        adiagonal(i)=A(pp,i);
    end
     i=i+1;
    if i>h && i>w
        k=2;
    end
end
sum_diagonal=sum(diagonal);
sum_adiagonal=sum(adiagonal);
    Lr=length(sum_row);
    Lc=length(sum_column);
    Ld=length(sum_diagonal);
    La=length(sum_adiagonal);
    LLL=Lr+Lc+Ld+La;
    u=1;
    j=1;
    y=1;
    o=1;
    z=1;
    while u<=LLL
        while j<=Lr
        sum_list(u)=sum_row(j);
        j=j+1;
        u=u+1;
        end
        while y<=Lc
        sum_list(u)=sum_column(y);
        y=y+1;
        u=u+1;
        end
        while o<=Ld
        sum_list(u)=sum_diagonal(o);
        o=o+1;
        u=u+1;
        end
        while z<=La
        sum_list(u)=sum_adiagonal(z);
        z=z+1;
        u=u+1;
        end
    end
sum_list=sum_list';
end

function HW4P4_update_board_SmithKR(game_state);

if game_state.player == 1
    text(game_state.x_click+0.1, game_state.y_click+0.55,'X',FontSize=110, color = 'b')
else
    text(game_state.x_click+0.05, game_state.y_click+0.55,'O',FontSize=110, color = 'r')
end
end

function [x,y]=HW4P7_get_valid_click_SmithKR(game_state);
valid=0;
while valid==0;
    i=0;
    c=ginput(1);
    x=floor(c(1));
    y=floor(c(2));
    if c(1)>4 || c(1)<1 || c(2)<1 || c(2)>4
        valid=0;
    else
        i=1;
    end
    if i==1;
        L=HW4P5_click_2_index_SmithKR(x,y);
        if game_state.empty_space(L) == true
            valid=1;
        end
    end
end
end

function abs_index=HW4P5_click_2_index_SmithKR(x,y);
f1=floor(x);
f2=floor(y);
matrix=([3 6 9; 2 5 8; 1 4 7;]);
abs_index=matrix(f2,f1);
end
