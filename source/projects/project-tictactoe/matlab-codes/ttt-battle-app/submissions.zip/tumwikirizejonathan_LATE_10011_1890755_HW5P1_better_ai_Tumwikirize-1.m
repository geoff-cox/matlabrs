% Author: Jonathan Tumwikirize 
% Date: 9th November 2023
% HR: Looked through how to iterate through struct fields for operations
% right after line 39! 
% https://www.mathworks.com/matlabcentral/answers/473601-looping-through-
% different-fields-in-struct
%
% Description: This program returns an AI move to an available space in a
% Tic-Tac-Toe game based on the following srategy:
%             Priority 1: If winning move available, take it.
%             Priority 2: Blocks potential opposing winning move.                               
%             Priority 3: Selects a space at random
%
function winning_move = HW5P1_better_ai_Tumwikirize(state)
%
where = char(64);

% To depict which elements of sum_rows_cols corresponds to. Cannot use
% number in fieldnames, so used characters that will be converted in the
% code. 
move = struct('A', [1 4 7], ... % row 1
              'B', [2 5 8], ... % row 2
              'C', [3 6 9], ... % row 3
              'D', [1 2 3], ... % col 1
              'E', [4 5 6], ... % col 2
              'F', [7 8 9], ... % col 3
              'G', [1 5 9], ... % diag 
              'H', [3 5 7]);    % adiag

% Edited HW4P9 to return a vector of all available moves. 
selection = HW4P9_dumb_ai_move_Tumwikirize(state);

% Sum every row, col etc to determine where someone may be winning.
sum_list = HW3P10_row_col_diag_sums_Tumwikirize(state);

% If player one, find where its winning. 
if state.player == 1
    for i = 1:length(sum_list)
        if sum_list(i) == 2
          where = char(i+64);
          break;
        elseif sum_list(i) == -2            
          where = char(i+64);
        end
    end
end

% If player two, find where its winning.
if state.player == -1
    for i = 1:length(sum_list)
        if sum_list(i) == -2
          where = char(i+64);
          break;
        elseif sum_list(i) == 2
          where = char(i+64);
        end
    end
end

% Using which quadrant from (where), find the winning move. 
if where ~= char(64)
    for i = 1:length(selection)
        for k = 1:length(move.(where))
            if selection(i) == move.(where)(k)
                winning_move = selection(i);
                break;
            end
        end
    end
else 
    winning_move = selection(randi(length(selection)));
end




%% Functions Used: HW3P10
function sum_list = HW3P10_row_col_diag_sums_Tumwikirize(state)
%
% Initialize Values
A = state.data;
[rows, cols] = size(A);
sum_list = [];

% Sum of Rows
for i = 1:rows 
    sum_list = [sum_list sum(A(i,:))];
end

% Sum of columns 
for i = 1:cols
    sum_list = [sum_list sum(A(:,i))];
end

% Diagnols
if rows < cols
    temp_sum_diag = 0;
    for i = 1:rows
       temp_sum_diag = temp_sum_diag + A(i,i);
    end
 
else 
    temp_sum_diag = 0;
    for i = 1:cols
       temp_sum_diag = temp_sum_diag + A(i,i);
    end
end
sum_list = [sum_list temp_sum_diag];

    
% Anti-Diagnol 
temp_sum_adiag = 0;
temp_sol = rows + 1;
for i = 1:rows
    for k = 1:cols
        if (i + k)  == temp_sol
            temp_sum_adiag = temp_sum_adiag + A(i,k);
        end
    end
end
sum_list = [sum_list temp_sum_adiag];

%% Functions Used: HW4P9
function selection = HW4P9_dumb_ai_move_altered_Tumwikirize(state)
%
[rows, cols] = size(state.data);
avl_qdrt = [];
vec = [];

mtx = [1 4 7;
       2 5 8;
       3 6 9];

for i = 1:rows
    for k = 1:cols
        if state.data(i, k) == 0
        avl_qdrt = [avl_qdrt; i k];
        end
    end
end

for i = 1:size(avl_qdrt)
    vec(i) = mtx(avl_qdrt(i, 1) , avl_qdrt(i, 2));
end

if ~isempty(vec)
    selection = vec;
else
    selection = [];
end




