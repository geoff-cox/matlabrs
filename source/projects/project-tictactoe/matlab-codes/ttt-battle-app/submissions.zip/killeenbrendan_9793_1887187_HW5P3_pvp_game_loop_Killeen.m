% Brendan Killeen
% HR: None

%%
function [game_state] = HW5P3_pvp_game_loop_Killeen(game_state)

round_counter = 0;               % turn counter to end game at 9 turns

while game_state.winner == 0

    round_counter = round_counter + 1;    % start a new round

    [x,y] = HW4P7_get_valid_click_Killeen(game_state);  % X's turn
    abs_index = HW4P5_click_2_index_Killeen(x,y);

    game_state.data(abs_index) = 1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'X';
    game_state.player = 1;
    game_state.empty_space(abs_index) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);     % add marks to the board

    result = HW4P8_winner_check_Killeen(game_state);
    game_state.winner = result;

    if game_state.winner ~= 0                   % kil the game if there's a winner
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end
    
    [x,y] = HW4P7_get_valid_click_Killeen(game_state);  % O's turn
    abs_index = HW4P5_click_2_index_Killeen(x,y);

    game_state.data(abs_index) = -1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'O';
    game_state.player = -1;
    game_state.empty_space(abs_index) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);

    result = HW4P8_winner_check_Killeen(game_state);
    game_state.winner = result;

    if game_state.winner ~= 0
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end

end

% results
% the title of the game interface displays the results
if game_state.winner == 1
    disp('X is the Winner!') 
elseif game_state.winner == -1
    disp('O is the Winner!')
else
    disp("It's a Draw!")
end

end

%% HELPER FUNCTIONS

% Valid Click
function [x,y] = HW4P7_get_valid_click_Killeen(game_state)

valid = false;                  % initialize while loop

while valid == false

    click = ginput(1);
    x_test = floor(click(1));
    y_test = floor(click(2));

    if x_test >= 4 || y_test >= 4
        continue
    elseif x_test < 1 || y_test < 1
        continue
    end

    abs_index = HW4P5_click_2_index_Killeen(x_test,y_test);

    if game_state.empty_space(abs_index) == 1
        x = x_test;
        y = y_test;
        valid = true;
    end
    
end

end

% Click to Index
function [abs_index] = HW4P5_click_2_index_Killeen(x,y)

index = [3, 6, 9;...
         2, 5, 8;...
         1, 4, 7];

abs_index = index(y,x)

end

% Update the Board
function [] = HW4P4_update_board_Killeen(game_state)

x = game_state.x_click;
y = game_state.y_click;

if game_state.player == -1
    text(x+0.2, y+0.53, 'O', 'color', 'blue', 'FontSize', 50)

elseif game_state.player == 1
    text(x+0.25, y+0.5, 'X', 'color', 'red', 'FontSize', 50)

end

end

% Check for Winner
function [result] = HW4P8_winner_check_Killeen(game_state)

sums = HW3P10_row_col_diag_sums_Killeen(game_state.data);

% if any of the sums are 3 or -3, then winner is 1 or -1, otherwise it
% returns 0

result = 0;             % initialize result

for idx = 1:length(sums)

    if sums(idx) == 3
        result = 1;
        break

    elseif sums(idx) == -3
        result = -1;
        break
    end

end

game_state.winner = result;

end

% Row/Column/Diagonal Sums
function [sum_list] = HW3P10_row_col_diag_sums_Killeen(A)

[m, n] = size(A);           % store dimensions of A

for i = 1:m
    row = A(i,:);           % set up temporary row vector
    row_sum(i) = sum(row);  % sum temporary row, store in vector
end

% TRANSPOSE THESE FUNCTIONS WHEN INSERTING INTO SUM LIST

for j = 1:n
    col = A(:,j);           % set up temp column vector
    col_sum(j) = sum(col);  % sum temporary column, store in vector
end

% REFERENCE SMALLEST DIMENSION AS INDEX FOR DIAGONALS
if m <= n
    least = m;              % establishing which dimension is smaller
else
    least = n;
end


for idx = 1:least
    diagonal(idx) = A(idx,idx);  % take the diagonal

end

row_count = m;
count = 1;                       % establish a counter to reference column
for jdx = least:-1:1
        antidiag(count) = A(row_count,count);    % for every loop, A(least-1,count+1)
        row_count = row_count - 1;
        count = count + 1;
end


diag_sum = sum(diagonal);
anti_sum = sum(antidiag);

sum_list = [row_sum';col_sum';diag_sum';anti_sum'];

end
