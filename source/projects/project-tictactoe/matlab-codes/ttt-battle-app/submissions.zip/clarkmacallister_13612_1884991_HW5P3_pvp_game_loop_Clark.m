function [state] = HW5P3_pvp_game_loop_Clark(game_state)

i = 1;
while i <= 9
[x,y] = HW4P7_get_valid_click_Clark(game_state);
index = HW4P5_click_2_index_Clark(x,y);
game_state.data(index) = game_state.player;
game_state.round = game_state.round + 1;
game_state.empty_space(index) = false;
game_state.x_click = x;
game_state.y_click = y;
HW4P4_update_board_Clark(game_state);
if HW4P8_winner_check_Clark(game_state.data) == 1 || ...
        HW4P8_winner_check_Clark(game_state.data) == -1
    game_state.winner = HW4P8_winner_check_Clark(game_state.data);
    break
end
game_state.player = game_state.player*-1;
end
end

% HW 4 P 7
function [x,y] = HW4P7_get_valid_click_Clark(game_state)

valid = 0;

while valid == 0
    click = ginput(1);
    xc = floor(click(1));
    yc = floor(click(2));
    if xc < 1 || xc > 3
        valid = 0;
    elseif yc < 1 || yc > 3
        valid = 0;
    elseif game_state.empty_space(HW4P5_click_2_index_Clark(xc,yc)) == 1
        x = xc;
        y = yc;
        valid = 1;
    else
        valid = 0;
    end
end
end

% HW 4 P 5
function [abs_index] = HW4P5_click_2_index_Clark(x,y)

matrix = [3 6 9;2 5 8;1 4 7];
abs_index = matrix(y,x);
end

% HW 4 P 8
function [result] = HW4P8_winner_check_Clark(data)
answers = HW3P10_row_col_diag_sums_Clark(data);
la = length(answers);
result = 0;
for i =1:la
if answers(i) == 3
    result = 1;
elseif  answers(i) == -3
    result = -1;
end
end
end
%Hw3 P10
function [sum_list] = HW3P10_row_col_diag_sums_Clark(A)
% Smith KR helped me find my error with my anti-diag sum calculator.  I
% researched how to put different size vectors into the same vector until i
% realized thats not how that works and figured out how to do the actual
% thing on my own.
HH=A(1:end,1);
BB=length(HH);
CC=1;
DD=zeros(1:BB);
while CC<=BB
    DD(CC)=sum(A(CC,1:end));
    CC=CC+1;
end
GG=A(1,1:end);
II=length(GG);
Mac=length(GG);
JJ=[];
FF=1;
while FF <= II
    JJ(FF)=sum(A(1:end,FF));
    FF=FF+1;
end
LL=1;
MM=0;
if BB >II
    Aa=II;
else 
    Aa=BB;
end
while LL <=Aa
    MM=MM+A(LL,LL);
    LL=LL+1;
end
OO=0;
PP=1;
x=0;
while x==0
if II >0 && PP <=BB
    OO=OO+A(PP, II);
    II=II-1;
    PP=PP+1;
    x=0;
else
    x=1;
end
end
Cc=1;
Dd=[];
while Cc<=BB
    Dd(Cc)=DD(Cc);
    Cc=Cc+1;
end
Ff=1;
while Cc <=Mac+BB
    Dd(Cc)=JJ(Ff);
    Ff=Ff+1;
    Cc=Cc+1;
end
Dd(Cc)=MM;
Dd(Cc+1)=OO;
sum_list=pagetranspose(Dd);
end

% HW 4 P 4
function HW4P4_update_board_Clark(game_state)

if game_state.player == 1
    text(game_state.x_click+0.08,game_state.y_click+0.55,'X', ...
        FontSize = 110,Color='y');
else
    text(game_state.x_click,game_state.y_click+0.55,'O', ...
        FontSize = 110, Color='g');
end
end