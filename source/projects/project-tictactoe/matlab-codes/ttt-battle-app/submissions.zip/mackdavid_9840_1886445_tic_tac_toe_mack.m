%hr:in class help
%mack,DL
clear 
clc

int_state=struct('data',zeros(3),...
    'round',0,...
    'winner',0,...
    'whos_turn','x',...
    'player',1,...
    'empty_space',[1 1 1 1 1 1 1 1 1],...
    'x_click',0,...
    'y_click',0);

% create the user input 
game_mode=questdlg ('What game mode do you want to play','Game_mode_selector','PvP','PvE','EvE','PvP');
if game_mode == 'PvP'
    state=int_state;
    Hw4p3_display_initial_board_mack;
    state = Hw5P3_pvp_game_loop_mack(state);
end
if game_mode == 'PvE'
    state=int_state;
    ai_O_level = questdlg('What dificulty','ai level selector','1','2','3','1');
    Hw4p3_display_initial_board_mack
    state = Hw5P4_pve_game_loop_mack(state,ai_O_level);
end
if game_mode == 'EvE'
    state=int_state;
    ai_O_level = questdlg('What dificulty','ai level selector','1','2','3','1');
    ai_X_level = questdlg('What dificulty','ai level selector','1','2','3','1');
    Hw4p3_display_initial_board_mack
    state = Hw5P5_eve_loop_mack(state,ai_X_level,ai_O_level);
end

% ask for the ai level
function Hw4P3 = Hw4p3_display_initial_board_mack
hold on
axis([.5 4.5 .5 4.5])

plot([2 2],[1 4],'k','linewidth',3)
plot([3 3],[1 4],'k','linewidth',3)
plot([1 4],[2 2],'k','linewidth',3)
plot([1 4],[3 3],'k','linewidth',3)

end
function state = Hw5P3_pvp_game_loop_mack(state)
for k=1:9
    state.round=k;
    if state.whos_turn=='x'|| state.whos_turn=='X'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
         Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(abs_index)=0; 
        state.data(abs_index)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
%
   
    end
    if state.whos_turn=='o'||state.whos_turn=='O'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(abs_index)=0;
        
        state.data(abs_index)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
    end
end
end
function [x, y] = Hw4P7_get_valid_click_mack(state)
x=0;
y=0;
c=0;
while c==0
k = ginput(1);
    if 1 <= k(1) && k(1) < 4 && k(2) >= 1 && k(2) < 4
        W = floor(k(1));
        Z = floor(k(2));
        abs_index = Hw4P5_click_2_index_mack(W,Z);
        if state.empty_space(1,abs_index) == 1
        x = floor(k(1));
        y = floor(k(2));
        c=1;
        end
   
    end
end
end
function state = Hw5P4_pve_game_loop_mack(state,ai_O_level)
%is the ai level going to be dermined in the struct
for k=1:9
    state.round=k;
    x=0;
    y=0;
    if state.whos_turn=='x'|| state.whos_turn=='X'
        [x, y] = Hw4P7_get_valid_click_mack(state);
        state.x_click=x;
        state.y_click =y;
         Hw4P4_update_board_mack(state);
        abs_index = Hw4P5_click_2_index_mack(x,y);
        state.empty_space(1,abs_index)=0; 
        state.data(abs_index)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
%
   
    end
    if state.whos_turn=='o'||state.whos_turn=='O'
        
        if ai_O_level == '1'
            selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '2'
            selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '3'
            selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(1,selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
            

            
    end

end
end
function state = Hw5P5_eve_loop_mack(state,ai_X_level,ai_O_level)
for k=1:9
    x=0;
    y=0;
    if state.player == 1
    if ai_X_level == '1'
        selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    if ai_X_level == '2'
        selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    if ai_X_level == '3'
        selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == 1
            state.winner=1;
            return
        end
        state.whos_turn='o';
        state.player=-1;
    end
    end
    if state.player == -1 
        if ai_O_level =='1' 
            selection = Hw4P9_dumb_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '2'
            selection = HW5P1_better_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
        if ai_O_level == '3'
            selection = Hw5P2_my_ai_move_mack(state);
            [x,y] = Hw4P6_index_2_click_mack(selection);
        
        state.x_click=x;
        state.y_click =y;
        Hw4P4_update_board_mack(state);
        
        state.empty_space(selection)=0;
        
        state.data(selection)=-1;
        result = Hw4P8_winner_check_mack(state.data);
        if result == -1
            state.winner=-1;
            return
        end
        state.whos_turn='x';
        state.player=1;
        end
    end


end
end

function update_board = Hw4P4_update_board_mack(game_state)



% game_state=struct('data',data...
%     ,'round',round...
%     ,'winner',winner...
%     ,'whos turn',whos_turn...
%     , 'player',player...
%     , 'empty space', empy_space...
%     , 'x click',x_click,'y click', y_click)



game_state;
game_state.whos_turn
game_state.x_click
game_state.y_click
hold on
if game_state.whos_turn == 'X'||game_state.whos_turn == 'x'
    %text 
    text(game_state.x_click+.3,game_state.y_click+.5,'X','color','blue','FontSize',50)
    
end
if game_state.whos_turn == 'O'||game_state.whos_turn =='o'
    text(game_state.x_click+.25,game_state.y_click+.5,'O','color','red','FontSize',50)
end

end

function abs_index = Hw4P5_click_2_index_mack(x,y)
if x==1
    if y==1
        abs_index=3;
    end
    if y==2
        abs_index=2;
    end
    if y==3
        abs_index=1;
    end
end
if x==2
    if y==1
        abs_index = 6;
    end
    if y==2
        abs_index = 5;
    end
    if y== 3
        abs_index = 4;
    end
end
if x==3
    if y==1
        abs_index = 9;
    end
    if y== 2 
        abs_index = 8;
    end
    if y==3
        abs_index = 7;
    end
end
end

function [x,y] = Hw4P6_index_2_click_mack(abs_index)
if abs_index == 1
    x = 1;
    y = 3;
end
if abs_index == 2 
    x=1;
    y=2;
end
if abs_index == 3 
    x=1;
    y=1;
end
if abs_index == 4
    x=2;
    y=3;
end
if abs_index == 5
    x=2;
    y=2;
end
if abs_index == 6 
    x=2;
    y=1;
end
if abs_index == 7
    x=3;
    y=3;
end
if abs_index == 8
    x=3;
    y=2;
end
if abs_index == 9 
    x=3;
    y=1;
end
end

function result = Hw4P8_winner_check_mack(data)

    sum_list = Hw3P10_row_col_diag_sums_mack(data);
    h=height(sum_list);
    for k=1:h
        if sum_list(k,1)==-3
            result = -1;
            
            break
        else
            result = 0;
        end
        if sum_list(k,1) == 3
            result = 1;
            
            break
        else
            result = 0;
        end
    end

end
function sum_list = Hw3P10_row_col_diag_sums_mack(A)
col_sum=sum(A);
row_sum=sum(A,2);
X=1;
Y=1;
Z=size(A);
C=1;
R = length(col_sum);
T = length(row_sum);
while X<=Z(2)&&Y<=Z(1)
    diagn(C) = A(Y,X);
    X=X+1;
    Y=Y+1;
    C=C+1;
end
Y=Z(1);
C=1;
X=1;
while X<=Z(2)&&Y>=1
    anti_diagn(C)=A(Y,X);
    X=X+1;
    Y=Y-1;
    C=C+1;
end
sum_anti_diag=sum(anti_diagn);
sum_diag=sum(diagn);
sum_list = zeros((Z(1)+Z(2)+2),1);
sum_list(1:T,1)=row_sum;
sum_list(T+1:T+R,1) = col_sum';
sum_list(T+R+1,1)=sum_diag;
sum_list(T+R+2,1)=sum_anti_diag;
end

function selection = Hw4P9_dumb_ai_move_mack(state)
l=length(state.empty_space);

for k=1:l
    Z=randi(9);
    if state.empty_space([1,k])==1
        selection = Z;
        break
    else 
        selection = [];
    end
end



end

