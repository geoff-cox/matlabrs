%HW5P5_eve_game_loop
function game_state=HW5P5_eve_game_loop_smithc(game_state, ai_x_level, ai_o_level)
for i=1:9
if i==1 || i==3|| i==5|| i==7|| i==9
    game_state.whos_turn='X'
    game_state.player=1
else
    
    game_state.whos_turn='O'
    game_state.player=-1
end
 
if game_state.whos_turn=='X'
    if ai_x_level=='1'
    S=HW4P9_dumb_ai_move_smithc(game_state)
    [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=1
    elseif ai_x_level=='2'
        S=HW5P1_better_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)   
    game_state.data(A)=1
    else
        S=HW5P2_my_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=1
    end
else 
    if ai_o_level=='1'
    S=HW4P9_dumb_ai_move_smithc(game_state)
    [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=-1
    elseif ai_o_level=='2'
        S=HW5P1_better_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)   
    game_state.data(A)=-1
    else
        S=HW5P2_my_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=-1
    end
end 
game_state.empty_space(A)=0
HW4P4_update_board_smithc(game_state)

W=HW4P8_winner_check_smithc(game_state.data)
if W==-1 && game_state.player==-1
    game_state.winner=-1
elseif W==1 && game_state.player==1
    game_state.winner=1
else
    game_state.winner=0
end

if game_state.winner== 1||game_state.winner==-1
      return 
end

game_state=game_state
end 
end

%HW4P8_winner_check_smithc
function result=HW4P8_winner_check_smithc(data)
M=data
if M(1)==1 && M(4)==1 && M(7)==1
    result=1; 
elseif M(2)==1 && M(5)==1 && M(8)==1
    result=1;
elseif M(3)==1 && M(6)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(2)==1 && M(3)==1
    result=1;
elseif M(4)==1 && M(5)==1 && M(6)==1
    result=1;
elseif M(7)==1 && M(8)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(5)==1 && M(9)==1
    result=1;
elseif M(7)==1 && M(5)==1 && M(3)==1
    result=1;
elseif M(1)==-1 && M(4)==-1 && M(7)==-1
    result=-1;
elseif M(2)==-1 && M(5)==-1 && M(8)==-1
    result=-1;
elseif M(3)==-1 && M(6)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(2)==-1 && M(3)==-1
    result=-1;
elseif M(4)==-1 && M(5)==-1 && M(6)==-1
    result=-1;
elseif M(7)==-1 && M(8)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(5)==-1 && M(9)==-1
    result=-1;
elseif M(7)==-1 && M(5)==-1 && M(3)==-1
    result=-1;
else 
    
    result=0;
end
end 