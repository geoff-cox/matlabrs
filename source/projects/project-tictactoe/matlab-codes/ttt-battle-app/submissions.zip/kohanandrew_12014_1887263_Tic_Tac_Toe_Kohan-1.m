answer = questdlg('Select Tic Tac Toe Game',...
    'Game Type',...
    'Player Vs Player', 'Player Vs Computer', 'Computer Vs Computer','Computer Vs Computer');
switch answer
    case 'Player Vs Player'
        ttt_pvp_script
    case 'Player Vs Computer'
        ttt_pve_script
    case 'Computer Vs Computer'
        ttt_eve_script
end