% HR: none
% James Wynn
% 11/14/2023
% 
% HW 5 P 7
% Given two input list with same length, returns number of common elements

function count = HW5P7_any_matches_Wynn(list1, list2)

    n1 = length(list1);
    n2 = length(list2);
    c = 0;
    count = 0;

    for k = 1:n1
        
        for g = 1:n2

            if list1(k) == list2(g)
    
                c = c + 1;
                break
    
            end
        end

        if c > count

            list2(g) = [];
            n2 = n2 - 1;

        end

        count = c;
    end
end