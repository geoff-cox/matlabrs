function state = HW5P3_pvp_game_loop_DOUGHERTY(state)

game_over = HW4P8_winner_check_DOUGHERTY(state.data);

while game_over == 0
    if state.round > 8
        break
    end

    [state.x , state.y] = HW4P7_get_valid_click_DOUGHERTY;
    HW4P4_update_board_DOUGHERTY(state)

    index = HW4P5_click_2_index_DOUGHERTY(state.x , state.y);


    if state.player == 1
        state.data(index) = 1;
    elseif state.player == -1
        state.data(index) = -1;
    end

    state.round = state.round + 1;

    game_over = HW4P8_winner_check_DOUGHERTY(state.data);

    if game_over == 1
        state.winner = 1;
        state.empty_space(index) = 0;
        break
    elseif game_over == -1
        state.winner = -1;
        state.empty_space(index) = 0;
        break
    end

    if state.whos_turn == 'X'
        state.whos_turn = 'O';
    elseif state.whos_turn == 'O'
        state.whos_turn = 'X';
    end

    if state.player == 1
        state.player = -1;
    elseif state.player == -1
        state.player = 1;
    end

    state.empty_space(index) = 0;

    game_over = HW4P8_winner_check_DOUGHERTY(state.data);

end

end

function result = HW4P8_winner_check_DOUGHERTY(data)

result = 0;
a = HW3P10_row_col_diag_sums_DOUGHERTY(data);
A = a';
i = length(A);
for n = 1 : i
    if abs(A(n)) == 3
        if A(n) == 3
            result = 1;
            break
        elseif A(n) == -3
            result = -1;
            break
        end
    end
end

end

function sum_list = HW3P10_row_col_diag_sums_DOUGHERTY(A)
[m , n] = size(A);
sum_list = [];

for k = 1 : m
    Sum = 0;
    for j = 1 : n
        Sum = Sum + A(k , j);
    end
    sum_list = [sum_list ; Sum];
end

for k = 1 : n
    Sum = 0;
    for j = 1 : m
        Sum = Sum + A(j , k);
    end
    sum_list = [sum_list ; Sum];
end

if m < n
    Sum = 0;
    for k = 1 : m
        Sum = Sum + A(k , k);
    end
    sum_list = [sum_list ; Sum];
else
    Sum = 0;
    for k = 1 : n
        Sum = Sum + A(k , k);
    end
    sum_list = [sum_list ; Sum];
end


Sum = 0;
q = 1;
if m < n
    while m >= 1
        Sum = Sum +  A(m , q);
        q = q + 1;
        m = m - 1;
    end
else
    while n >= 1
        Sum = Sum + A(m , q);
        q = q + 1;
        m = m - 1;
        n = n - 1;
    end
end

sum_list = [sum_list ; Sum];

end

function [x , y] = HW4P7_get_valid_click_DOUGHERTY(state)

[x , y] = ginput(1);

while (x > 4 || x < 1) || ((y > 4) || (y < 1))
    [x , y] = ginput(1);
    x = floor(x);
    y = floor(y);
    index = HW4P5_click_2_index_DOUGHERTY(x , y);

    while state.empty_space(1 , index) == 0
        [x , y] = ginput(1);
        index = HW4P5_click_2_index_DOUGHERTY(x , y);
    end

end

x = floor(x);
y = floor(y);

end

function abs_index =  HW4P5_click_2_index_DOUGHERTY(x , y)

if x == 1
    a = [3 2 1];
    abs_index = a(y);
elseif x == 2
    a = [6 5 4];
    abs_index = a(y);
elseif x == 3
    a = [9 8 7];
    abs_index = a(y);
end

end

function HW4P4_update_board_DOUGHERTY(state)

if state.player == 1
    text(state.x + 0.15 , state.y + 0.54 , 'X' , 'Color' , 'blue' , 'Fontsize' , 70)
elseif state.player == -1
    text(state.x + 0.08 , state.y + 0.53 , 'O' , 'Color' , 'blue' , 'Fontsize' , 70)
end

end








