% HR: none
% James Wynn
% 11/14/2023
% 
% HW 5 P 6
% Given two input list, function returns number of ordered equal elements

function count = HW5P6_exact_matches_Wynn(list1, list2)


    n1 = length(list1);
    n2 = length(list2);
    count = 0;

    if n1 < n2

        n = n1;

    else

        n = n2;

    end

    for k = 1:n

        if list1(k) == list2(k)

            count = count + 1;

        end
    end
end