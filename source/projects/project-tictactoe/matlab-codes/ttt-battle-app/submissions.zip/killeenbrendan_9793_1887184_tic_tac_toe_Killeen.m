% Brendan Killeen
% HR: Canvas Tests

%% GAME SETUP

clear
clc
close all

game_state.data = zeros(3,3);
game_state.round = 0;
game_state.winner = 0;
game_state.whos_turn = 'X'
game_state.player = 1;
game_state.empty_space = [1 1 1 1 1 1 1 1 1];
game_state.x_click = 0;
game_state.y_click = 0;

game_mode = questdlg('What game mode would you like to play?','Game Select','PvP','PvE','EvE','PvE');

HW4P3_display_initial_board_Killeen

%% GAME LOOP

switch game_mode

    case 'PvP'
        HW5P3_pvp_game_loop_Killeen(game_state);
        % capture output game state
    case 'PvE'
        ai_O_level = questdlg('Select Game Difficulty','Difficulty Select','1','2','3','1');
        HW5P4_pve_game_loop_Killeen(game_state,ai_O_level);

    case 'EvE'
        ai_X_level = questdlg('Select X Difficulty','X Difficulty Select','1','2','3','1');
        ai_O_level = questdlg('Select O Difficulty','O Difficulty Select','1','2','3','1');
        HW5P5_eve_game_loop_Killeen(game_state,ai_X_level,ai_O_level);

end

%% RESULTS

% somehow get the results in the title

%% HELPER FUNCTIONS

% Display the Initial Board
function [board] = HW4P3_display_initial_board_Killeen()

grid on
axis equal
hold on

plot([1,4],[2,2],'k','LineWidth',3)
plot([1,4],[3,3],'k','LineWidth',3)
plot([2,2],[1,4],'k','LineWidth',3)
plot([3,3],[1,4],'k','LineWidth',3)

xlim([0.5,4.5])
ylim([0.5,4.5])

end

% PVP Game Loop
function [game_state] = HW5P3_pvp_game_loop_Killeen(game_state)

round_counter = 0;               % turn counter to end game at 9 turns

while game_state.winner == 0

    round_counter = round_counter + 1;    % start a new round

    [x,y] = HW4P7_get_valid_click_Killeen(game_state);  % X's turn
    abs_index = HW4P5_click_2_index_Killeen(x,y);

    game_state.data(abs_index) = 1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'X';
    game_state.player = 1;
    game_state.empty_space(abs_index) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);     % add marks to the board

    result = HW4P8_winner_check_Killeen(game_state.data);
    game_state.winner = result;

    if game_state.winner ~= 0                   % kil the game if there's a winner
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end
    
    [x,y] = HW4P7_get_valid_click_Killeen(game_state);  % O's turn
    abs_index = HW4P5_click_2_index_Killeen(x,y);

    game_state.data(abs_index) = -1;             % update all immediate values
    game_state.round = round_counter;
    game_state.whos_turn = 'O';
    game_state.player = -1;
    game_state.empty_space(abs_index) = 0;
    game_state.x_click = x;
    game_state.y_click = y;

    HW4P4_update_board_Killeen(game_state);

    result = HW4P8_winner_check_Killeen(game_state.data);
    game_state.winner = result;

    if game_state.winner ~= 0
        break
    end

    if sum(game_state.empty_space) == 0
        break
    end

end


end

% PVE Game Loop
% ADD ONCE AI ARE COMPLETE

% EVE Game Loop
% ADD ONCE AI ARE COMPLETE

% Valid Click
function [x,y] = HW4P7_get_valid_click_Killeen(game_state)

valid = false;                  % initialize while loop

while valid == false

    click = ginput(1);
    x_test = floor(click(1));
    y_test = floor(click(2));

    if x_test >= 4 || y_test >= 4
        continue
    elseif x_test < 1 || y_test < 1
        continue
    end

    abs_index = HW4P5_click_2_index_Killeen(x_test,y_test);

    if game_state.empty_space(abs_index) == 1
        x = x_test;
        y = y_test;
        valid = true;
    end
    
end

end

% Click to Index
function [abs_index] = HW4P5_click_2_index_Killeen(x,y)

index = [3, 6, 9;...
         2, 5, 8;...
         1, 4, 7];

abs_index = index(y,x)

end

% Index to Click
function [x,y] = HW4P6_index_2_click_Killeen(abs_index)

x_coords = [1, 2, 3;...
            1, 2, 3;...
            1, 2, 3];

y_coords = [3, 3, 3;...
            2, 2, 2;...
            1, 1, 1];

x = x_coords(abs_index)
y = y_coords(abs_index)

end

% Update the Board
function [] = HW4P4_update_board_Killeen(game_state)

x = game_state.x_click;
y = game_state.y_click;

if game_state.player == -1
    text(x+0.2, y+0.53, 'O', 'color', 'blue', 'FontSize', 50)

elseif game_state.player == 1
    text(x+0.25, y+0.5, 'X', 'color', 'red', 'FontSize', 50)

end

end

% Check for Winner
function [result] = HW4P8_winner_check_Killeen(data)

sums = HW3P10_row_col_diag_sums_Killeen(data);

% if any of the sums are 3 or -3, then winner is 1 or -1, otherwise it
% returns 0

result = 0;             % initialize result

for idx = 1:length(sums)

    if sums(idx) == 3
        result = 1;
        break

    elseif sums(idx) == -3
        result = -1;
        break
    end

end

end

% Row/Column/Diagonal Sums
function [sum_list] = HW3P10_row_col_diag_sums_Killeen(A)

[m, n] = size(A);           % store dimensions of A

for i = 1:m
    row = A(i,:);           % set up temporary row vector
    row_sum(i) = sum(row);  % sum temporary row, store in vector
end

% TRANSPOSE THESE FUNCTIONS WHEN INSERTING INTO SUM LIST

for j = 1:n
    col = A(:,j);           % set up temp column vector
    col_sum(j) = sum(col);  % sum temporary column, store in vector
end

% REFERENCE SMALLEST DIMENSION AS INDEX FOR DIAGONALS
if m <= n
    least = m;              % establishing which dimension is smaller
else
    least = n;
end


for idx = 1:least
    diagonal(idx) = A(idx,idx);  % take the diagonal

end

row_count = m;
count = 1;                       % establish a counter to reference column
for jdx = least:-1:1
        antidiag(count) = A(row_count,count);    % for every loop, A(least-1,count+1)
        row_count = row_count - 1;
        count = count + 1;
end


diag_sum = sum(diagonal);
anti_sum = sum(antidiag);

sum_list = [row_sum';col_sum';diag_sum';anti_sum'];

end

% Dumb AI
function [selection] = HW4P9_dumb_ai_move_Killeen(game_state)

selection = randi(9);

while game_state.empty_space(selection) == 0
    selection = randi(9);

    if game_state.empty_space == zeros(1,9)
        selection = [];
        break
    end

end

end

% Better AI
% ADD ONCE COMPLETE

% My AI Strategy
% ADD ONCE COMPLETE
