function selection = HW5P1_better_ai_move_miller(game_state)
%%Name:Sean Miller
%%Help Received:None
for c=1:9
if game_state.data(c)==0
check=game_state.data; 
check(c)=game_state.player-2;
if HW4P8_winner_check_miller(check)==-1
    selection=c;
    return
end
end
end
for c=1:9
    if game_state.data(c)==0
        check=game_state.data;
        check(c)=game_state.player;
        if HW4P8_winner_check_miller(check)==1
            selection=c;
        end
    end
end
for c=1:9
    if game_state.data(c)==0
        check=game_state.data;
        check(c)=game_state.player;
        if HW4P8_winner_check_miller(check)==0
            selection=HW4P9_dumb_ai_move_miller(check);
        end
    end
end
end