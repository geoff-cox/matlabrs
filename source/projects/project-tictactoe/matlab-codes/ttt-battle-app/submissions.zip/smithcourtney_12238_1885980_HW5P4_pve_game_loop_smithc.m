%HW5P4_pve_game_loop_smithc
function game_state=HW5P4_pve_game_loop_smithc(game_state, ai_o_level)

for i=1:9
if i==1 || i==3|| i==5|| i==7|| i==9
    game_state.whos_turn='X'
    game_state.player=1
else
    
    game_state.whos_turn='O'
    game_state.player=-1
end
 
if game_state.whos_turn=='X'
    [game_state.x_click, game_state.y_click]=HW4P7_get_valid_click_smithc(game_state)
    A=HW4P5_click_2_index_smithc(game_state.x_click,game_state.y_click)
    game_state.data(A)=1
else 
    if ai_o_level=='1'
    S=HW4P9_dumb_ai_move_smithc(game_state)
    [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=-1
    elseif ai_o_level=='2'
        S=HW5P1_better_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)   
    game_state.data(A)=-1
    else
        S=HW5P2_my_ai_move_smithc(game_state)
         [game_state.x_click, game_state.y_click]=HW4P6_index_2_click_smithc(S)
    A=HW4P5_click_2_index_smithc(game_state.x_click, game_state.y_click)
    game_state.data(A)=-1
    end
end 
game_state.empty_space(A)=0
HW4P4_update_board_smithc(game_state)

W=HW4P8_winner_check_smithc(game_state.data)
if W==-1 && game_state.player==-1
    game_state.winner=-1
elseif W==1 && game_state.player==1
    game_state.winner=1
else
    game_state.winner=0
end

if game_state.winner== 1||game_state.winner==-1
      return 
end

game_state=game_state
end 
end
 


%HW5P2_my_ai_move_smithc
function selection=HW5P2_my_ai_move_smithc(game_state)
E=game_state.data;
k=1;
c=0;
i=1;
M=zeros(1,9);
P=game_state.player
while k<=9
    if E(k)== 0
        M(i)=k;
        i=i+1;
        k=k+1;
        c=c+1;
    else
        k=k+1;
    end
end
M(c+1:end)=[]
l=length(M)
data=game_state.data
T= data(6)

 
for h=1:l
   data=game_state.data
   data(M(h))= P
   W=HW4P8_winner_check_smithc(data)
   
   if W==P
       selection=M(h)
        data=game_state.data
        return
        
   else 
        data=game_state.data
   end 
end 
for n=1:l
     data=game_state.data
     data(M(n))= -1*P
     W=HW4P8_winner_check_smithc(data)
    if W==true 
        selection=M(n)
        return
    else
        data=game_state.data
    end
end 

   if data(6)==0
        selection= 6
        return
    else 
      game_state.data=game_state.data 
   end
    
 for j=1:l
     if data(1)==0
         selection=1
     elseif data(7)==0
         selection=7
     elseif data(3)== 0
         selection=3 
     elseif data(9)==0
         selection=9
     else 
         for z=1:l
     data=game_state.data 
    if c==0
        selection=[];   
    else
    L=length(M);
    R=randi(L);
    selection=M(R);
    end
         end
end 
 end

end





%HW4P8_winner_check_smithc
function result=HW4P8_winner_check_smithc(data)
M=data
if M(1)==1 && M(4)==1 && M(7)==1
    result=1; 
elseif M(2)==1 && M(5)==1 && M(8)==1
    result=1;
elseif M(3)==1 && M(6)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(2)==1 && M(3)==1
    result=1;
elseif M(4)==1 && M(5)==1 && M(6)==1
    result=1;
elseif M(7)==1 && M(8)==1 && M(9)==1
    result=1;
elseif M(1)==1 && M(5)==1 && M(9)==1
    result=1;
elseif M(7)==1 && M(5)==1 && M(3)==1
    result=1;
elseif M(1)==-1 && M(4)==-1 && M(7)==-1
    result=-1;
elseif M(2)==-1 && M(5)==-1 && M(8)==-1
    result=-1;
elseif M(3)==-1 && M(6)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(2)==-1 && M(3)==-1
    result=-1;
elseif M(4)==-1 && M(5)==-1 && M(6)==-1
    result=-1;
elseif M(7)==-1 && M(8)==-1 && M(9)==-1
    result=-1;
elseif M(1)==-1 && M(5)==-1 && M(9)==-1
    result=-1;
elseif M(7)==-1 && M(5)==-1 && M(3)==-1
    result=-1;
else 
    
    result=0;
end
end 

%HW5P1_better_ai_move_smithc
function selection=HW5P1_better_ai_move_smithc(game_state)
E=game_state.data;
k=1;
c=0;
i=1;
M=zeros(1,9);
P=game_state.player
while k<=9
    if E(k)== 0
        M(i)=k;
        i=i+1;
        k=k+1;
        c=c+1;
    else
        k=k+1;
    end
end
M(c+1:end)=[]
l=length(M)


for h=1:l
   game_state.data=game_state.data
   game_state.data(M(h))= P
   W=HW4P8_winner_check_smithc(game_state.data)
   
   if W==P
       selection=M(h)
        game_state.data=game_state.data
        return
        
   else 
        game_state.data=game_state.data
   end 
end 
for n=1:l
      game_state.data=game_state.data
      game_state.data(M(n))= -1*P
     W=HW4P8_winner_check_smithc( game_state.data)
    if W==true 
        selection=M(n)
        return
    else
         game_state.data=game_state.data
    end
end 
for j=1:l
      game_state.data=game_state.data 
    if c==0
        selection=[];   
    else
    L=length(M);
    R=randi(L);
    selection=M(R);
    end
end 

end

%HW4P9_dumb_ai_move_smithc
function selection=HW4P9_dumb_ai_move_smithc(game_state)
E=game_state.empty_space;
k=1;
c=0;
i=1;
M=zeros(1,9);
while k<=9
    if E(k)== 1
        M(i)=k;
        i=i+1;
        k=k+1;
        c=c+1;
    else
        k=k+1;
    end
end
M(c+1:end)=[];

    if c==0
        selection=[];
    else
L=length(M);
R=randi(L);
selection=M(R);
    
    end
end

%HW4P6__index_2_click_smithc
function [x,y] =HW4P6_index_2_click_smithc(abs_index)
if abs_index==1
    x= 1;
    y=3;
elseif abs_index==2
    x=1;
    y=2;
elseif abs_index==3
    x=1;
    y=1;
elseif abs_index==4
    x=2;
    y=3;
elseif abs_index==5
    x=2;
    y=2;
elseif abs_index==6
    x=2;
    y=1;
elseif abs_index==7
    x=3;
    y=3;
elseif abs_index==8
    x=3;
    y=2;
else
    x=3;
    y=1;
end
    
    

end

