%tic_tac_toe_smithc
%%%%%Game Setup%%%%%
data= [0 0 0; 0 0 0; 0 0 0]
round=0
winner= 0
whos_turn= 'X'
player=1 
empty_space= [1 1 1 1 1 1 1 1 1]
x_click= 0
y_click= 0
game_state= struct(...
    'data',data, ...
    'round',round, ...
    'winner',winner, ... 
    'whos_turn',whos_turn,... 
    'player', player,  ...
    'empty_space', empty_space, ...
    'x_click', x_click,  ...
    'y_click', y_click) 
%initial board
 plot([2,2],[1,4], '-b', 'LineWidth', 3)
 hold on 
 plot ([1,4],[2,2], '-b', 'LineWidth', 3)
 hold on 
 plot([1,4],[3,3],'-b','LineWidth',3)
hold on 
plot([3,3],[1,4],'-b','LineWidth', 3)
axis equal 
axis off
ax = gca; 
ax.XColor = 'none';
ax.YColor = 'none';

%Encoding Question Dialouge Box
answer=questdlg('What Game Type Would You Like To Play?', ...
    'Choose Game Type',...
    'Player vs Player', 'Player vs Environment','Environment vs Environment','Player vs Player')

%%%Handle Response 
switch answer
    case 'Player vs Player'
        game_state=HW5P3_pvp_game_loop_smithc(game_state)
    case 'Player vs Environment'
        ai_o_level=questdlg('What Level Would You Like To Play?',...
            'Choose AI Level',...
            'Easy','Medium','Hard','Easy')
        switch ai_o_level
            case 'Easy'
                ai_o_level='1'
            case 'Medium'
                ai_o_level='2'
            case 'Hard' 
                ai_o_level='3'
        end
        game_state=HW5P4_pve_game_loop_smithc(game_state, ai_o_level)
    case 'Environment vs Environment'
        ai_x_level= questdlg('What Level Would You Like To Play?',...
            'Choose AI Level X Player',...
            'Easy', 'Medium', 'Hard','Easy')
        switch ai_x_level
            case 'Easy'
                ai_x_level='1'
               
            case 'Medium'
                
                ai_x_level='2'
            case 'Hard'
                
                ai_x_level='3'
        end
        
        ai_o_level=questdlg('What Level Would You Like To Play?', ...
            'Choose AI Level O Player',...
            'Easy', 'Medium', 'Hard', 'Easy')
        switch ai_o_level
            case 'Easy'
                ai_o_level='1'
            case 'Medium'
                ai_o_level='2'
            case 'Hard'
                ai_o_level='3'
        end
        game_state=HW5P5_eve_game_loop_smithc(game_state,ai_x_level, ai_o_level) 
end
    
                


%Win Statement 
if game_state.winner== -1 
    title('O WINS')
elseif game_state.winner== 1 
    title('X WINS')
else   
    title('DRAW')
end






