game_state.data = [0 0 0; 0 0 0; 0 0 0];
game_state.round = 0;
game_state.winner = 0;
game_state.whos_turn = 'X';
game_state.player = 1;
game_state.empty_space = [1 1 1 1 1 1 1 1 1];
game_state.x_click = 0;
game_state.y_click = 0;

answer_player = questdlg('What game mode would you like to play?', ...
    'Game Options', ...
    '2 Player','1 Player','AI vs AI', 'AI vs AI');
switch answer_player
    case '2 Player'
    case '1 Player'
        answer_level = questdlg ('What competetion level do you want to face aganist?',...
            'AI Levels',...
            'Level 1', 'Level 2', 'Level 3', 'Level 3');
        switch answer_level
            case 'Level 1'
                ai_O_level = 1;
            case 'Level 2'
                ai_O_level = 2;
            case 'Level 3'
                ai_O_level = 3;
        end
    case 'AI vs AI'
        answer_levels = questdlg ('Please select player 1 difficulty level.',...
            'AI Levels',...
            'Level 1','Level 2', 'Level 3', 'Level 3');
        switch answer_levels
            case 'Level 1'
                ai_X_level = 1;
            case 'Level 2'
                ai_X_level = 2;
            case 'Level 3'
                ai_X_level = 3;
        end
        answer_option = questdlg('Please select player 2 difficulty level.',...
            'AI levels',...
            'Level 1', 'Level 2', 'Level 3', 'Level 3');
        switch answer_option
            case 'Level 1'
                ai_O_level = 1;
            case 'Level 2'
                ai_O_level = 2;
            case 'Level 3'
                ai_O_level = 3;
        end
end
HW4P3_display_initial_board_EYNON
switch answer_player
    case '2 Player'
        [game_state] = HW5P3_pvp_game_loop_EYNON(game_state);
    case '1 Player'
        [game_state] = HW5P4_pve_game_loop_EYNON(game_state,ai_O_level);
    case 'AI vs AI'
        [game_state] = HW5P5_eve_game_loop_EYNON(game_state,ai_X_level,ai_O_level);
end
function [game_state] = HW5P3_pvp_game_loop_EYNON(game_state)

    while game_state.winner == 0
        game_state.round = game_state.round + 1;
        if game_state.round > 9
            game_state.winner = 0;
            break
    elseif mod(game_state.round,2) == 1
            game_state.whos_turn = 'X';
            [x,y] = HW4P7_get_valid_click_EYNON(game_state);
            game_state.x_click = x;
            game_state.y_click = y;
            [abs_index] = HW4P5_click_2_index_EYNON(x,y);
            game_state.data(x,y) = 1; 
            game_state.empty_space(abs_index) = 0;
            HW4P4_update_board_EYNON(game_state)
            [result] = HW4P8_winner_check_EYNON(game_state.data);
            game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        else 
            game_state.whos_turn = 'O';
            [x,y] = HW4P7_get_valid_click_EYNON(game_state);
            game_state.x_click = x;
            game_state.y_click = y;
            [abs_index] = HW4P5_click_2_index_EYNON(x,y);
            game_state.data(x,y) = -1; 
            game_state.empty_space(abs_index) = 0;
            HW4P4_update_board_EYNON(game_state)
            [result] = HW4P8_winner_check_EYNON(game_state.data);
            game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        end
    end
end
function [x,y] = HW4P7_get_valid_click_EYNON(game_state)

while true
    [a,b] = ginput(1);
    if (a < 4 && a >= 1) && (b < 4 && b >= 1)
        break
    else 
        for k = 1:length(game_state.empty_space)
            if k == 0
                break
           end
       end
    end
end
x = floor(a);
y = floor(b);
end
function [abs_index] = HW4P5_click_2_index_EYNON(x,y)

a = floor(x);
b = floor(y);

if a == 1  && b == 3
    abs_index = 1;
elseif a == 1 && b == 2
    abs_index = 2;
elseif a == 1 && b == 1
    abs_index = 3;
elseif a == 2 && b == 3
    abs_index = 4;
elseif a == 2 && b == 2
    abs_index = 5;
elseif a == 2 && b == 1
    abs_index = 6;
elseif a == 3 && b == 3
    abs_index = 7;
elseif a == 3 && b == 2
    abs_index = 8;
elseif a == 3 && b == 1
    abs_index = 9;
end
end
function HW4P4_update_board_EYNON(game_state)

if game_state.whos_turn == 'X'
    text(game_state.x_click + .15,game_state.y_click + .5, game_state.whos_turn, 'fontsize', 100)
else 
    text(game_state.x_click + .1,game_state.y_click + .53, game_state.whos_turn, 'fontsize', 100)
    if game_state.winner == 1
        title('Player X wins')
    elseif game_state.winner == -1
        title('Player O wins')
    elseif game_state.winner == 0
        title('This game ends in a tie')
    end
end
end
function [result] = HW4P8_winner_check_EYNON(data)

    [nrows, ncol] = size(data);
    result = 0;

    for r = 1:nrows
        if sum(data(r,:)) == 3 || sum(data(r,:)) == -3
                result = sum(data(r,:))/3;
                break
        end
    end
    for c = 1:ncol
        if sum(data(:,c)) == 3 || sum(data(:,c)) == -3
            result = (sum(data(:,c)))/3;
            break
        end
    end
    if data(1,1) + data(2,2) + data(3,3) == 3 || data(1,1) + data(2,2) + data(3,3) == -3
        result = data(1,1) + data(2,2) + data(3,3)/3;
    elseif data(3,1) + data(2,2) + data(1,3) == 3 || data(3,1) + data(2,2) + data(1,3) == -3 
        result = data(3,1) + data(2,2) + data(1,3)/3;
    end
end
function [selection] = HW4P9_dumb_ai_move_EYNON(game_state)

E = length(game_state.empty_space);
c = 1;
    for k = 1:length(game_state.empty_space)
        if game_state.empty_space(k) == true
           E(c) = k;
           c = c + 1;
        else
            selection = [];
        end
    end
z = randi(c-1);
selection = E(z);
end
function [selection] = HW5P1_better_ai_move_EYNON(game_state)

[nrows, ncol] = size(game_state.data);

if game_state.whos_turn =='X'
    x = 1;
elseif game_state.whos_turn == 'O'
    x = -1;
end

 for r = 1:nrows
     for c = 1:ncol
         if HW4P8_winner_check_EYNON(game_state.data) == 2*x  
             selection = HW4P5_click_2_index_EYNON(r,c);
         elseif HW4P8_winner_check_EYNON(game_state.data) == -2*x  
             selection = HW4P5_click_2_index_EYNON(r,c);
         else
             selection = HW4P9_dumb_ai_move_EYNON(game_state);
         end
     end
 end
end
function [selection] = HW5P2_my_ai_move_EYNON(game_state)

if game_state.empty_space(5) == 1
    selection = 5;
    return
elseif game_state.empty_space(1) == 1
    selection = 1;
    return
elseif game_state.empty_space(3) == 1
    selection = 3;
    return
elseif game_state.empty_space(7) == 1
    selection = 7;
    return
elseif game_state.empty_space(9) == 1
    selection = 9;
    return
end

if game_state.whos_turn == 'X'
    if game_state.data(1,1) == 1 && game_state.data(1,3) == 1
        selection = 4;
        return
    elseif game_state.data(1,1) == 1 && game_state.data(3,1) == 1
        selection = 2;
        return
    elseif game_state.data(1,3) == 1 && game_state.data(3,3) == 1
        selection = 8;
        return
    elseif game_state.data(3,1) == 1 && game_state.data(3,3) == 1
        selection = 6;
        return
    end
else
    if game_state.data(1,1) == -1 && game_state.data(1,3) == -1
        selection = 4;
    end
    if game_state.data(1,1) == -1 && game_state.data(3,1) == -1
        selection = 2;
    end
    if game_state.data(1,3) == -1 && game_state.data(3,3) == -1
        selection = 8;
    end
    if game_state.data(3,1) == -1 && game_state.data(3,3) == -1
        selection = 6;
    else 
        [selection] = HW5P1_better_ai_move_EYNON(game_state);
    end
end
end
function [x,y] = HW4P6_index_2_click_EYNON(abs_index)

if abs_index == 1
    x = 1;
    y = 3;
elseif abs_index == 2
    x = 1;
    y = 2;
elseif abs_index == 3
    x = 1;
    y = 1;
elseif abs_index == 4
    x = 2;
    y = 3;
elseif abs_index == 5
    x = 2;
    y = 2;
elseif abs_index == 6
    x = 2;
    y = 1;
elseif abs_index == 7
    x = 3;
    y = 3;
elseif abs_index == 8
    x = 3;
    y = 2;
elseif abs_index == 9
    x = 3;
    y = 1;
end
end
function [game_state] = HW5P5_eve_game_loop_EYNON(game_state,ai_X_level,ai_O_level)

while game_state.winner == 0
    game_state.round = game_state.round + 1;
    if game_state.round > 9
        game_state.winner = 0;
        break
    elseif mod(game_state.round,2) == 1
        game_state.whos_turn = 'X';
        if ai_X_level == 1
            [selection] = HW4P9_dumb_ai_move_EYNON(game_state);
        elseif ai_X_level == 2
            [selection] = HW5P1_better_ai_move_EYNON(game_state);
        else
            [selection] = HW5P2_my_ai_move_EYNON(game_state);
        end
        [x,y] = HW4P6_index_2_click_EYNON(selection);
        game_state.x_click = x;
        game_state.y_click = y;
        [abs_index] = HW4P5_click_2_index_EYNON(x,y);
        game_state.data(x,y) = 1;
        game_state.empty_space(abs_index) = 0;
        HW4P4_update_board_EYNON(game_state)
        [result] = HW4P8_winner_check_EYNON(game_state.data);
        game_state.winner = result;
        if game_state.winner ~= 0
            return
        end
    else
        game_state.whos_turn = 'O';
        if ai_O_level == 1
            [selection] = HW4P9_dumb_ai_move_EYNON(game_state);
        elseif ai_O_level == 2
            [selection] = HW5P1_better_ai_move_EYNON(game_state);
        else
            [selection] = HW5P2_my_ai_move_EYNON(game_state);
        end
        [x,y] = HW4P6_index_2_click_EYNON(selection);
        game_state.x_click = x;
        game_state.y_click = y;
        [abs_index] = HW4P5_click_2_index_EYNON(x,y);
        game_state.data(x,y) = -1;
        game_state.empty_space(abs_index) = 0;
        HW4P4_update_board_EYNON(game_state)
        [result] = HW4P8_winner_check_EYNON(game_state.data);
        game_state.winner = result;
        if game_state.winner ~= 0
            return
        end
    end
end
end
function [game_state] = HW5P4_pve_game_loop_EYNON(game_state,ai_O_level)
  
while game_state.winner == 0
    game_state.round = game_state.round + 1;
        if game_state.round > 9
            game_state.winner = 0;
            break
    elseif mod(game_state.round,2) == 1
            game_state.whos_turn = 'X';
            [x,y] = HW4P7_get_valid_click_EYNON(game_state);
            game_state.x_click = x;
            game_state.y_click = y;
            [abs_index] = HW4P5_click_2_index_EYNON(x,y);
            game_state.data(x,y) = 1; 
            game_state.empty_space(abs_index) = 0;
            HW4P4_update_board_EYNON(game_state)
            [result] = HW4P8_winner_check_EYNON(game_state.data);
            game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        else 
            game_state.whos_turn = 'O';
           if ai_O_level == 1
               [selection] = HW4P9_dumb_ai_move_EYNON(game_state);
           elseif ai_O_level == 2
                [selection] = HW5P1_better_ai_move_EYNON(game_state);
           else
               [selection] = HW5P2_my_ai_move_EYNON(game_state);
           end
           [x,y] = HW4P6_index_2_click_EYNON(selection);
           game_state.x_click = x;
           game_state.y_click = y;
           [abs_index] = HW4P5_click_2_index_EYNON(x,y);
           game_state.data(x,y) = -1; 
           game_state.empty_space(abs_index) = 0;
           HW4P4_update_board_EYNON(game_state)
           [result] = HW4P8_winner_check_EYNON(game_state.data);
           game_state.winner = result;
            if game_state.winner ~= 0
                return
            end
        end
end
end