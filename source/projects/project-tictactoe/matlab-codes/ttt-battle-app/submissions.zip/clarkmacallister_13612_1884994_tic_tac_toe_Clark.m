% HR looked up the command to close all figures.
close all
user = questdlg('What kind of game would you like to play?',...
    'Tic Tac Toe', 'player vs player', 'player vs enviroment', ...
    'enviroment vs enviroment', 'enviroment vs enviroment');

switch user 
    case 'player vs player'
        HW4P3_display_intial_board_Clark
        HW5P3_pvp_game_loop_Clark(game_state)
    case 'player vs enviroment'
        ai = questdlg('How hard of an ai would you like to play?', ...
            'ai level', '1', '2', '3', '3');
        switch ai
            case '1'
                HW4P3_display_intial_board_Clark
                game_state.ai_O_level = 1;
                HW5P4_pve_game_loop_Clark(game_state)
            case '2'
                 HW4P3_display_intial_board_Clark
                game_state.ai_O_level = 2;
                HW5P4_pve_game_loop_Clark(game_state)
            case '3'
                 HW4P3_display_intial_board_Clark
                game_state.ai_O_level = 3;
                HW5P4_pve_game_loop_Clark(game_state)
        end
    case 'enviroment vs enviroment'
        aix = questdlg('Select level for ai 1 (x)', 'ai x level', ...
            '1', '2','3', '3');
        switch aix 
            case '1'
                game_state.ai_x_level = 1;
                aio = questdlg('Select level for ai 2 (o)', 'ai o level', ...
            '1', '2','3', '3');
                switch aio
                    case '1'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 1;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '2'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 2;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '3'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 3;
                        HW5P5_eve_game_loop_Clark(game_state)
                end
            case '2'
                game_state.ai_x_level = 2;
                aio = questdlg('Select level for ai 2 (o)', 'ai o level', ...
            '1', '2','3', '3');
                switch aio
                    case '1'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 1;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '2'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 2;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '3'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 3;
                        HW5P5_eve_game_loop_Clark(game_state)
                end
            case '3'
                game_state.ai_x_level = 3;
                aio = questdlg('Select level for ai 2 (o)', 'ai o level', ...
            '1', '2','3', '3');
                switch aio
                    case '1'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 1;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '2'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 2;
                        HW5P5_eve_game_loop_Clark(game_state)
                    case '3'
                        HW4P3_display_intial_board_Clark
                        game_state.ai_o_level = 3;
                        HW5P5_eve_game_loop_Clark(game_state)
                end
        end
end

% HW 4 P 3
function HW4P3_display_intial_board_Clark

f = figure;
hold on
f.Position(1:4) = [200 50 600 650];
plot([2 2] , [1 4], LineWidth=3,Color="#000")
plot([3 3] , [1 4], LineWidth=3,Color="#000")
plot([1 4] , [3 3], LineWidth=3,Color="#000")
plot([1 4] , [2 2], LineWidth=3,Color="#000")
axis([0.5 4.5 0.5 4.5])
grid on
axis equal
end