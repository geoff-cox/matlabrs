%hr:in class help
%mack,DL
function selection = HW5P1_better_ai_move_mack(state)

l=length(state.empty_space);
selection = 0;
orig=state.data;
tst=state.data;
    %sum_list = Hw3P10_row_col_diag_sums_mack(state);
    for k=1:l
            if state.empty_space(k)==1
                tst(k)=1;
                result = Hw4P8_winner_check_mack(tst);
                if result==1
                    selection =k;
                    return
                else
                    tst=orig;
                end
           
                tst(k)=-1;
                result = Hw4P8_winner_check_mack(tst);
                if result == -1
                    selection =k;
                    return
                else
                    tst=orig;
                end
            end
    end
    if selection == 0  
        selection = Hw4P9_dumb_ai_move_mack(state);
    end
end
