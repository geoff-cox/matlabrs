HW4P3_display_initial_board_Dougherty

state.data = zeros(3);
state.round = 0;
state.winner = 0;
state.whos_turn = 'X';
state.player = 1;
state.empty_space = [1 1 1 1 1 1 1 1 1];

answer = questdlg('What type of game?' , ...
    'Type' , ...
    'PVP' , 'PVE' , 'EVE' , 'EVE');

switch answer
    case 'PVP'
        state = HW5P3_pvp_game_loop_DOUGHERTY(state)
    case 'PVE'
        O_mode = questdlg('What O mode?' , ...
            'Mode' , ...
            '1' , '2' , '3' , '3');
        switch O_mode
            case '1'
                ai_O_level = 1;
            case '2'
                ai_O_level = 2;
            case '3'
                ai_O_level = 3;
        end

        state = HW5P4_pve_game_loop_DOUGHERTY(state , ai_O_level);
    case 'EVE'
        O_mode = questdlg('What O mode?' , ...
            'Mode' , ...
            '1' , '2' , '3' , '3');
        X_mode = questdlg('What X mode?' , ...
            'Mode' , ...
            '1' , '2' , '3' , '3');
        switch O_mode
            case '1'
                ai_O_level = 1;
            case ' 2'
                ai_O_level = 2;
            case '3'
                ai_O_level = 3;
        end
        
        switch X_mode
            case '1'
                ai_X_level = 1;
            case '2'
                ai_X_level = 2;
            case '3'
                ai_X_level = 3;
        end

        state = HW5P5_eve_game_loop_DOUGHERTY(state , ai_X_level , ai_O_level)
end


        



