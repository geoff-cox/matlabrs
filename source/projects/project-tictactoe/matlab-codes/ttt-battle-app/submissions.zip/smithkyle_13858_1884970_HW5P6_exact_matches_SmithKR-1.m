function [count] = HW5P6_exact_matches_SmithKR(list1,list2);
i=1;
count=0;
L1=length(list1);
L2=length(list2);
if L1>L2
    L=L2;
else
    L=L1;
end

while i<=L
    if list1(i)==list2(i)
        count=count+1;
    end
    i=i+1;
end