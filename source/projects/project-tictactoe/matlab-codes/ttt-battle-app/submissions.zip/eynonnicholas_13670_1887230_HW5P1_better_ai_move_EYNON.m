function [selection] = HW5P1_better_ai_move_EYNON(game_state)

[nrows, ncol] = size(game_state.data);

if game_state.whos_turn =='X'
    x = 1;
elseif game_state.whos_turn == 'O'
    x = -1;
end

 for r = 1:nrows
     for c = 1:ncol
         if HW4P8_winner_check_EYNON(game_state.data) == 2*x  
             selection = HW4P5_click_2_index_EYNON(r,c);
         elseif HW4P8_winner_check_EYNON(game_state.data) == -2*x  
             selection = HW4P5_click_2_index_EYNON(r,c);
         else
             selection = HW4P9_dumb_ai_move_EYNON(game_state);
         end
     end
 end
end