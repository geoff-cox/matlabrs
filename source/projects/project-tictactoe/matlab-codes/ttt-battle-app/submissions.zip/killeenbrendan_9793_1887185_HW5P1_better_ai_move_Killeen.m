% Brendan Killeen
% HR: none

%%
function [selection] = HW5P1_better_ai_move_Killeen(game_state)

for idx = 1:9
    % winning move
    temp = game_state.data;             % store game data in a temporary file
    if temp(idx) == 0                   % if the currently selected space is empty
        temp(idx) = game_state.player;  % add player code to a temp selection
        win_check = HW4P8_winner_check_Killeen(temp);  % do a winner check on the temp

        if win_check == game_state.player
            selection = idx;            % if it works, make it the selection
            return
        end
    end
end

for idx = 1:9
    % blocking move
    temp = game_state.data;             % store game data in a temporary file
    if temp(idx) == 0                   % if the currently selected space is empty
        temp(idx) = -game_state.player;  % add player code to a temp selection
        win_check = HW4P8_winner_check_Killeen(temp);  % do a winner check on the temp

        if win_check == -game_state.player
            selection = idx;            % if it works, make it the selection
            return
        end
    end
end

selection = HW4P9_dumb_ai_move_Killeen(game_state);

end     % FUNCTION END